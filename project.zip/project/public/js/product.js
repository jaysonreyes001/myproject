$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#employee_li').addClass('active'); 
$('#schedule_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
	var brand = $("#cmbBrand option:selected").val();
	var cat_no_1 = $("#cmbCat1 option:selected").val();
	var cat_no_2 = $("#cmbCat2 option:selected").val();
	var cat_no_3 = $("#cmbCat3 option:selected").val();
	var cat_no_4 = $("#cmbCat4 option:selected").val();
	var cat_no_5 = $("#cmbCat5 option:selected").val();
	var cat_no_6 = $("#cmbCat6 option:selected").val();
    var product_code = $('#txtProductcode').val();
    var price = $('#txtPrice').val();
    var description = $('#txtDescription').val();
    var button_text = $('#txtButtontext').val();
    var parent_code = $('#txtParentcode').val();
    var pos_text = $('#txtPostext').val();
    var tax_code = $('#txtTaxcode').val();
    var all_dis_code = $('#txtDiscountcode').val();
    var product_type = $('#txtProductType').val();
   //edit march 23 2021
   var cat_code_7 = $('#cat_code_7').val();
   var sequence = $("#sequence").val()
    var site = $('#site_url').val();
	var productmode = $("#productmode").val();
    $.ajax({
     url:'save_product',
     type:"post",
     data:{ id:id,
            brand: brand,
            cat_no_1: cat_no_1,
            cat_no_2: cat_no_2,
            cat_no_3: cat_no_3,
            cat_no_4: cat_no_4,
            cat_no_5: cat_no_5,
            cat_no_6: cat_no_6,
			cat_code_7:cat_code_7,
			sequence:sequence,
            product_code: product_code,
            price: price,
            description: description,
            button_text: button_text,
            parent_code: parent_code,
            pos_text: pos_text,
            tax_code: tax_code,
            all_dis_code: all_dis_code,
            product_type: product_type,
			product_mode:productmode
           
			},
       success: function(data){
        alert("Product has been saved successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteProduct(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'product/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Product successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeProduct(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'product/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Product successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}