$('#dashboard_li').removeClass('active');
$('#website_li').addClass('active'); 

$(document).ready(function(){

  $('#submit').submit(function(e){
    var title = $('#title').val();
    e.preventDefault(); 
    $.ajax({
     url:'Website/saveWebsite',
     type:"post",
     data:{title: title},
       success: function(data){
        $('#newHiring').modal('hide');
        alert("Website saved successfully.");
        location.reload(3000);
      }
    });
  });

});

function deleteWebsite(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Website/editWebsite',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Website successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeWebsite(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Website/editWebsite',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Website successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function newWebsite(){

  $('#newWebsite').modal('show');
}