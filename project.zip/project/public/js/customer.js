$(document).ready(function() { 
  var data = 0;

        $.ajax({
          type: 'POST',
          dataType: 'json',
          url: 'Customer/getallcustomers',
          success: function(result) {
          
           data = result;
            
          },
          error: function(result){
      //    alert("error");
          }
        });


$('#branch').change( function (){
  var branch = $('#branch').val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Customer/getbranchmessage',
    data:{'branch': branch},
    success: function(result) {
     $("#store_notes").html(result);
     $('#store_notes').text(result);
    },
    error: function(data){
   // alert("error");
    }
  });
  getBranchContact(branch);
});



$('#branch_list_code').change( function (){
  var branch = $('#branch_list_code').val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Customer/getbranchmessage',
    data:{'branch': branch},
    success: function(result) {
     $("#branch_message").html(result);
     $('#branch_message').text(result);
    },
    error: function(data){
   // alert("error");
    }
  });
});

$('#autocomplete').blur( function (){
  if($('#autocomplete').val() != ""){
    $('#branch').empty();
  }
});

var phone = document.getElementById("phone");

phone.addEventListener("keydown", function (e) {
    if (e.keyCode === 13 && phone != "") {  //checks whether the pressed key is "Enter"
       //searchCustomer(phone);
    // alert('gg');
   
    test=$('#phone').val();
    //alert(test);
       searchCustomer(test);
     $('#searchBody').text("Order successfully placed.");
     $('#search-modal').modal('show');
    
    
    }
});

$('#custom_search').click( function (){
  
  
   searchCustomer2($('#searchfn').val(),$('#searchln').val());
  
});

$('#fn2').chosen().change( function (){
  $('#fn').val($('#fn2').text());
  searchCustomerPhone2();
});

$("#cboMOP").change(function() {
  var mop = $("#cboMOP").val();
  if (mop == "AK"){
    $("#for_cash_div").css("display","none");
    $('#placeOrder1').removeClass("noclickme");
  }else{
    $("#for_cash_div").css("display","block");
    if ($("#amtRendered").val() == ""){
      $('#placeOrder1').addClass("noclickme");
    }else{
      $('#placeOrder1').removeClass("noclickme");
    }
  }
});


$('#searchbar1').on({
    keyup: function(e){
      if ($('#searchbar1').val() == ""){
        $('#searchbar1_div ul').empty();
        $('#searchbar1_div ul').hide();
      }else{
        $('#searchbar1_div ul').empty();

        $search = $(this).val();

        $search = new RegExp($search.replace(/[^0-9a-z_]/i), 'i');

        for(var i in data){
            if(data[i].name.match($search)){
                $('#searchbar1_div ul').append($("<li id = '" + data[i].id + "' onclick='selectCustomer(" + data[i].id + ")'><span class='suggest-name'>" + data[i].name + "</span><span class='suggest-description'>" + data[i].description + "</span></li>"));
            }
        }
        $('#searchbar1_div ul').show();
    }
  }
});

$('#searchbar2').on({
    keyup: function(e){
      if ($('#searchbar2').val() == ""){
        $('#searchbar2_div ul').empty();
        $('#searchbar2_div ul').hide();
      }else{
        $('#searchbar2_div ul').empty();

        $search = $(this).val();

        $search = new RegExp($search.replace(/[^0-9a-z_]/i), 'i');

        for(var i in data){
            if(data[i].name.match($search)){
                $('#searchbar2_div ul').append($("<li id = '" + data[i].id + "' onclick='selectCustomer(" + data[i].id + ")'><span class='suggest-name'>" + data[i].name + "</span><span class='suggest-description'>" + data[i].description + "</span></li>"));
            }
        }
        $('#searchbar2_div ul').show();
    }
  }
});

$('#searchbar').on({
    keyup: function(e){
      if ($('#searchbar').val() == ""){
        $('#searchbar_div ul').empty();
        $('#searchbar_div ul').hide();
      }else{
        $('#searchbar_div ul').empty();

        $search = $(this).val();

        $search = new RegExp($search.replace(/[^0-9a-z_]/i), 'i');

        for(var i in data){
            if(data[i].description.match($search)){
                $('#searchbar_div ul').append($("<li id = '" + data[i].id + "' onclick='selectCustomer(" + data[i].id + ")'><span class='suggest-name'>" + data[i].description + "</span><span class='suggest-description'>" + data[i].name + "</span></li>"));
            }
        }
        $('#searchbar_div ul').show();
    }
  }
});

  $("#searchbar, #searchbar1, #searchbar2").keyup(function(event) {
      if (event.keyCode === 13) {
         searchCustomer();
      }
  });

});
function changevis(){
  if($("#addnew").is(':checked')==true){
    $("#fieldfname2").css("display", "none")
    $("#fieldfname1").css("display", "block")
     clearallfields()
  }else{
    $("#fieldfname1").css("display", "none")
    $("#fieldfname2").css("display", "block")
    $("#fn2_chosen").css("width", "100%")
    searchCustomerPhone($('#phone').val());
    
    $("#fn2").trigger("chosen:updated");  
  }
}
function hideShowCustInfo(type,tab){
  if(type == 0){
    $('#customer_div').css('display','block');
    $('#sidebar_customer_div').css('display','none');
    $('#ordertaking_tab').removeClass("col-sm-12");
    $('#ordertaking_tab').addClass("col-sm-8");
    $('#ordertaking_tab').css('width','');
      if(tab == 1){
        $('#myTab a[href="#search"]').tab('show');
      }else if(tab == 2){
        $('#myTab a[href="#information"]').tab('show');
      }else if (tab == 3){
        $('#myTab a[href="#address"]').tab('show');
      }
  }else if(type == 1){
    $('#customer_div').css('display','none');
    $('#sidebar_customer_div').addClass("menu-min");
    $('#sidebar_customer_div').css('display','block');
    $('#ordertaking_tab').removeClass("col-sm-8");
    $('#ordertaking_tab').addClass("col-sm-12");
    $('#ordertaking_tab').css('width','96.5%');
  }
}


function clearallfields(){
      //$('#phone').val(data[0]['phone']);
            $('#phone').val('');
            $('#ext').val('');
            $('#custid').val('');
            $('#fn').val('');
            $('#mn').val('');
            $('#ln').val('');
      $('#addgg').val('');
      $('#autocomplete').val('');
      $('#custnameid').val('');
            $('#addressid').val('');
            $('#company').val('');
            $('#flr').val('');
            $('#bldg').val('');
            $('#hno').val('');
            $('#route').val('');
            $('#subdv').val('');
            $('#strt').val('');
            $('#brgy').val('');
            $('#administrative_area_level_1').val('');
            $('#locality').val('');
            $('#branch').val('');
            $('#notes').val('');
            $('#postal_code').val('');
            $('#country').val('');
      $('#custid_span').html('Customer: NEW');
      $('#orderid_span').text('Current Order ID : NEW');
}
function searchCustomerPhone(phone){
    clearallfields()
       $.ajax({
          type: 'POST',
          dataType: 'html',
          url: 'Customer/searchcustomerdetails2',
          data:{'phone': phone},
          success: function(result) {
           $("#fn2").html(result);
           $("#fn2").trigger("chosen:updated");;
          
          },
          error: function(data){
        //  alert("error");
          }
        });
    
}
function searchCustomerIdFinal(rowid){
  //selectCustomer($('#custnameid').val());
  
  get_orderid(rowid);
  //selectCustomer(rowid);
  $('#orderids').chosen().change( function (){
      //alert('test');
      
      $('#orderiddetails').val($('#orderids').val());
      $('#orderid_span').text('Current Order ID : ' + $('#orderids').val() );
      selectorderdetails($('#orderids').val());
    });
    
    $('#branch').empty();
  clearallfields()
   $.ajax({
          type: 'POST',

          dataType: 'json',
          url: 'Customer/searchcustomerdetails',
          data:{'rowid': rowid},
          success: function(data) {
            $('#phone').val(data[0]['phone']);
            $('#ext').val(data[0]['alt_phone']);
            $('#custid').val(data[0]['custid']);
            $('#fn').val(data[0]['firstname']);
            $('#mn').val(data[0]['middlename']);
            $('#ln').val(data[0]['lastname']);
            $('#addgg').val(data[0]['addgg']);
            $('#autocomplete').val(data[0]['addgg']);
            $('#Landmark').val(data[0]['landmark']);
            $('#custnameid').val(data[0]['ids']);
            $('#addressid').val(data[0]['ids']);
            $('#company').val(data[0]['loc']);
            $('#flr').val(data[0]['floor']);
            $('#bldg').val(data[0]['bldg']);
            $('#hno').val(data[0]['res_no']);
            $('#route').val(data[0]['block']);
            $('#subdv').val(data[0]['subdv']);
            $('#strt').val(data[0]['street_number']);
            $('#brgy').val(data[0]['phase']);
            $('#administrative_area_level_1').val(data[0]['district']);
            $('#locality').val(data[0]['city']);
            $('#branch').val(data[0]['branchcode']);
            $('#notes').val(data[0]['address_notes']);
            $('#postal_code').val(data[0]['zipcode']);
            $('#country').val(data[0]['country']);
      $('#custid_span').text('Customer: '+$('#fn').val()+' ID:'+$('#custnameid').val());
      
        var savecustdeets = data[0]['phone'] + "~" + data[0]['alt_phone'] + "~" + data[0]['firstname'] + "~" + data[0]['middlename'] + "~" + data[0]['lastname'] + "~" 
        + data[0]['addgg'] + "~" + '' + $('#Landmark').val() + "~" + data[0]['branchcode'];
        $('#savecustdetails').val(savecustdeets);
          
      $('#mapsearchgo').click();
      
      jsonTableGenerate('OrderTaking/testmark');
      $.ajax({
        type: 'POST',
        dataType: 'html',
        url: 'OrderTaking/renderTrans2',
        data:{'id': $('#custnameid').val()},
        success: function(result) {
        
         
          $('#result_order').html(result);
          var totalRows = $('#searchOrderResult').find('tbody tr:has(td)').length;
              var recordPerPage = 5;
              var totalPages = Math.ceil(totalRows / recordPerPage);
              var $pages = $('<div id="pages2"></div>');
              for (i = 0; i < totalPages; i++) {
              $('<button class="btn btn-minier btn-primary pageNumber2">&nbsp;' + (i + 1) + '</button>').appendTo($pages);
              }
              $pages.appendTo('#searchOrderResult');

              $('.pageNumber2').hover(
              function() {
                $(this).addClass('focus');
              },
              function() {
                $(this).removeClass('focus');
              }
              );

              $('#searchOrderResult').find('tbody tr:has(td)').hide();
              var tr = $('#searchOrderResult tbody tr:has(td)');
              for (var i = 0; i <= recordPerPage - 1; i++) {
              $(tr[i]).show();
              }
              $('.pageNumber2').click(function(event) {
              $('#searchOrderResult').find('tbody tr:has(td)').hide();
              var nBegin = ($(this).text() - 1) * recordPerPage;
              var nEnd = $(this).text() * recordPerPage - 1;
              for (var i = nBegin; i <= nEnd; i++) {
                $(tr[i]).show();
              }
              });
        },
        error: function(result){
        //alert("error");
        }
      });
      
          },
          error: function(data){
       //   alert("error");
          }
      });

   getBranchContact();
}

function getBranchContact(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Customer/getbranchcontact',
    data:{'branch': id},
    success: function(result) {
     $("#branch_number").html(result);
     $('#branch_number').text(result);
    },
    error: function(data){
   // alert("error");
    }
  });
}


function searchCustomerPhone2(){
  //selectCustomer($('#custnameid').val());
  rowid=$('#custnameid').val();
  get_orderid(rowid);
  $('#orderids').chosen().change( function (){
      //alert('test');
      
      $('#orderiddetails').val($('#orderids').val());
      $('#orderid_span').text('Current Order ID : ' + $('#orderids').val() );
      selectorderdetails($('#orderids').val());
    });
  clearallfields()
   $.ajax({
          type: 'POST',

          dataType: 'json',
          url: 'Customer/searchcustomerdetails',
          data:{'rowid': rowid},
          success: function(data) {
           $('#phone').val(data[0]['phone']);
            $('#ext').val(data[0]['alt_phone']);
            $('#custid').val(data[0]['custid']);
            $('#fn').val(data[0]['firstname']);
            $('#mn').val(data[0]['middlename']);
            $('#ln').val(data[0]['lastname']);
      $('#addgg').val(data[0]['addgg']);
      $('#autocomplete').val(data[0]['address1']);
      $('#custnameid').val(data[0]['ids']);
            $('#addressid').val(data[0]['ids']);
            $('#company').val(data[0]['loc']);
            $('#flr').val(data[0]['floor']);
            $('#bldg').val(data[0]['bldg']);
            $('#hno').val(data[0]['res_no']);
            $('#route').val(data[0]['block']);
            $('#subdv').val(data[0]['subdv']);
            $('#strt').val(data[0]['street_number']);
            $('#brgy').val(data[0]['phase']);
            $('#administrative_area_level_1').val(data[0]['district']);
            $('#locality').val(data[0]['city']);
            $('#branch').val(data[0]['branchcode']);
            $('#notes').val(data[0]['address_notes']);
            $('#postal_code').val(data[0]['zipcode']);
            $('#country').val(data[0]['country']);
      $('#custid_span').text('Customer: '+$('#fn').val()+' ID:'+$('#custnameid').val());
      
      jsonTableGenerate('OrderTaking/testmark');
      $.ajax({
        type: 'POST',
        dataType: 'html',
        url: 'OrderTaking/renderTrans',
        data:{'id': $('#custnameid').val()},
        success: function(result) {
        
         
          $('#transactionList').html(result);

        },
        error: function(result){
      //  alert("error");
        }
      });
      
          },
          error: function(data){
        //  alert("error");
          }
      });
}


function selectCustomer(id){

  $('#ordertaking_tab').removeClass("noclickme");
  $('#orderdetails_tab').removeClass("noclickme");
  $('#transviewer_tab').removeClass("noclickme");
  $('#transhistory_tab').removeClass("noclickme");
  $('#date-timepicker2').addClass("noclickme");
  $('#orderNote').removeClass("noclickme");
  $('#custinfo').show();
  $('#myTab a[href="#information"]').tab('show');
  $('#id').val(id);
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'Customer/customerdetails',
      data:{'id': id},
      success: function(data) {
      
          $('#id').val(data[0]['ids']);
          $('#phone').val(data[0]['phone']);
          $('#ext').val(data[0]['alt_phone']);
          $('#custid').val(data[0]['custid']);
      
          $('#fn').val(data[0]['fn']);
          $('#mn').val(data[0]['mn']);
          $('#ln').val(data[0]['ln']);
          $('#company').val(data[0]['loc']);
          $('#room').val(data[0]['flr']);
          $('#bldg').val(data[0]['blg']);
          $('#addressid').val(data[0]['rowid']);
          $('#company').val(data[0]['loc']);
          $('#flr').val(data[0]['floor']);
          $('#bldg').val(data[0]['bldg']);
          $('#hno').val(data[0]['res_no']);
          $('#blk').val(data[0]['block']);
          $('#subdv').val(data[0]['subdv']);
          $('#strt').val(data[0]['street']);
          $('#brgy').val(data[0]['phase']);
          $('#mun').val(data[0]['district']);
          $('#city').val(data[0]['city']);
          $('#branch').val(data[0]['branchcode']);
          $('#notes').val(data[0]['address_notes']);

    
        var savecustdeets = data[0]['phone'] + "~" + data[0]['alt_phone'] + "~" + data[0]['fn'] + "~" + data[0]['mn'] + "~" + data[0]['ln'] + "~" 
        + data[0]['res_no'] + "~" + data[0]['street'] + "~" + data[0]['flr'] + "~" + data[0]['loc'] + "~" + data[0]['bldg'] + "~" + ' ' + "~" 
        + data[0]['block'] + "~" + data[0]['phase'] + "~" + data[0]['subdv'] + "~" + data[0]['district'] + "~" + data[0]['city'] + "~" 
        + data[0]['address_notes'] + "~" + data[0]['branchcode'];
        $('#savecustdetails').val(savecustdeets);
      
       $.ajax({
          type: 'POST',
          dataType: 'html',
          url: 'Ordertaking/renderTrans',
          data:{'id': data[0]['custnameid']},
          success: function(result) {
          
            jsonTableGenerate('OrderTaking/testmark');
            $('#transactionList').html(result);
            
            
            
            
            
          },
          error: function(result){
        //  alert("error");
          }
        });
    
      
      
      },
      error: function(data){
      //  alert("error");
      }
  });

}
function showOrderDetail(id){
  $('#selectedorderid').val(id);

 $.ajax({
      type: 'POST',
      url: 'Supervisor/orderDetails',
      data:{'rowid': id},
      success: function(data) {
        var result = data.split("?");

        //$('#orderStatus').html(result[0]);
        //$('#customerHistory').html(result[1]);
        $('#orderHistory').html(result[0]);
      },
      error: function(data){
   //   alert("error");
      }
  });
  
}
function selectAddress(id){
    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'Customer/addressdetails',
        data:{'id': id},
        success: function(data) {
            $('#addressid').val(data[0]['rowid']);
            $('#phone').val(data[0]['phone']);
            $('#company').val(data[0]['loc']);
            $('#room').val(data[0]['room']);
            $('#bldg').val(data[0]['bldg']);
            $('#hno').val(data[0]['res_no']);
            $('#blk').val(data[0]['block']);
      
      

            $('#subdv').val(data[0]['subdv']);
            $('#strt').val(data[0]['street']);
            $('#brgy').val(data[0]['phase']);
            $('#mun').val(data[0]['district']);
            $('#city').val(data[0]['city']);
            $('#branch').val(data[0]['branchcode']);
            $('#notes').val(data[0]['address_notes']);
            $('#custinfo').show();
            $('#myTab a[href="#information"]').tab('show');
        },
        error: function(data){
      //    alert("error");
        }
    });
}

function clearSearch(){
  $('#searchbar').val('');
  $('#searchbar1').val('');
  $('#searchbar2').val('');
}


function searchphone(){
  var searchbar = $('#phone').val();
    var searchbar1 = $('#searchbar1').val();
    var searchbar2 = $('#searchbar2').val();
  $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'Customer/searchphone',
            data:{
                  'searchbar': searchbar,
                  'searchbar1': searchbar1, 
                  'searchbar2': searchbar2
                 },
            success: function(data) {
              if(data != ""){
        selectCustomer(data);             
              }
            },
            error: function(data){
         //     alert("error");
            }
        });
  
}

function searchCustomer2(fn,ln){
  xx="";
    var searchbar = xx;
    var searchbar1 = fn;
    var searchbar2 = ln;
  //searchbar='09973779407';
    if( searchbar1 == "" && searchbar2 == ""){
      alert("Please input search keywords.");
    }else{
       $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'Customer/searchcustomer',
            data:{
                  'searchbar': searchbar,
                  'searchbar1': searchbar1, 
                  'searchbar2': searchbar2
                 },
            success: function(data) {
              if(data != ""){
                $('#result_customer').html(data);
          
          var totalRows = $('#searchResultCust').find('tbody tr:has(td)').length;
              var recordPerPage = 5;
              var totalPages = Math.ceil(totalRows / recordPerPage);
              var $pages = $('<div id="pages"></div>');
              for (i = 0; i < totalPages; i++) {
              $('<button class="btn btn-minier btn-primary pageNumber">&nbsp;' + (i + 1) + '</button>').appendTo($pages);
              }
              $pages.appendTo('#searchResultCust');

              $('.pageNumber').hover(
              function() {
                $(this).addClass('focus');
              },
              function() {
                $(this).removeClass('focus');
              }
              );

              $('#searchResultCust').find('tbody tr:has(td)').hide();
              var tr = $('#searchResultCust tbody tr:has(td)');
              for (var i = 0; i <= recordPerPage - 1; i++) {
              $(tr[i]).show();
              }
              $('.pageNumber').click(function(event) {
              $('#searchResultCust').find('tbody tr:has(td)').hide();
              var nBegin = ($(this).text() - 1) * recordPerPage;
              var nEnd = $(this).text() * recordPerPage - 1;
              for (var i = nBegin; i <= nEnd; i++) {
                $(tr[i]).show();
              }
              });
              }else{
                $('#result_customer').html('<div class="alert alert-danger"><strong><i class="ace-icon fa fa-frown-o"></i>No results found.</strong>Try searching again.</div><br/>');
              }
            },
            error: function(data){
         //     alert("error");
            }
        });
    }
  }

function searchCustomer(xx){
    var searchbar = xx;
    var searchbar1 = $('#searchbar1').val();
    var searchbar2 = $('#searchbar2').val();
  //searchbar='09973779407';
    if(searchbar == "" && searchbar1 == "" && searchbar2 == ""){
      alert("Please input search keywords.");
    }else{
       $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'Customer/searchcustomer',
            data:{
                  'searchbar': searchbar,
                  'searchbar1': searchbar1, 
                  'searchbar2': searchbar2
                 },
            success: function(data) {
              if(data != ""){
                $('#result_customer').html(data);
          
          var totalRows = $('#searchResultCust').find('tbody tr:has(td)').length;
              var recordPerPage = 5;
              var totalPages = Math.ceil(totalRows / recordPerPage);
              var $pages = $('<div id="pages"></div>');
              for (i = 0; i < totalPages; i++) {
              $('<button class="btn btn-minier btn-primary pageNumber">&nbsp;' + (i + 1) + '</button>').appendTo($pages);
              }
              $pages.appendTo('#searchResultCust');

              $('.pageNumber').hover(
              function() {
                $(this).addClass('focus');
              },
              function() {
                $(this).removeClass('focus');
              }
              );

              $('#searchResultCust').find('tbody tr:has(td)').hide();
              var tr = $('#searchResultCust tbody tr:has(td)');
              for (var i = 0; i <= recordPerPage - 1; i++) {
              $(tr[i]).show();
              }
              $('.pageNumber').click(function(event) {
              $('#searchResultCust').find('tbody tr:has(td)').hide();
              var nBegin = ($(this).text() - 1) * recordPerPage;
              var nEnd = $(this).text() * recordPerPage - 1;
              for (var i = nBegin; i <= nEnd; i++) {
                $(tr[i]).show();
              }
              });
              }else{
                $('#result_customer').html('<div class="alert alert-danger"><strong><i class="ace-icon fa fa-frown-o"></i>No results found.</strong>Try searching again.</div><br/>');
              }
            },
            error: function(data){
         //     alert("error");
            }
        });
    }
  }

  function newAddress(){
    $('#addressid').val('');
    $('#company').val('');
    $('#flr').val('');
    $('#bldg').val('');
    $('#hno').val('');
    $('#blk').val('');
    $('#subdv').val('');
    $('#room').val('');
    $('#strt').val('');
    $('#brgy').val('');
    $('#mun').val('');
    $('#city').val('');
    $('#branch').val('');
    $('#myTab a[href="#information"]').tab('show');
    //$('#basicinformation').addClass("collapsed");
    //$('#basicinfobody').css('display','none');
  }

  function addNewCustomer(){
    $('#phone').val('');
    $('#ext').val('');
    $('#id').val('');
    $('#custid').val('');
    $('#ln').val('');
    $('#fn').val('');
    $('#mn').val('');
    $('#addressid').val('');
    $('#company').val('');
    $('#flr').val('');
    $('#bldg').val('');
    $('#hno').val('');
    $('#blk').val('');
    $('#subdv').val('');
    $('#strt').val('');
    $('#brgy').val('');
    $('#mun').val('');
    $('#city').val('');
    $('#custinfo').show();
    $('#myTab a[href="#information"]').tab('show');
  }

  
  function saveDetails(){
  //selectCustomer($('#custnameid').val());
    
    var id = $('#id').val();
    var custid = $('#custid').val();
    var phone = $('#phone').val();
    var loc = $('#company').val();
  //if($("#addnew").is(':checked')==true){
  //  var fn = $('#fn').val();
  //  var addnew=0;
  //}else{
  //    var fn = $('#fn').val();  
  //  var addnew=$('#fn2').val();
  //}
  var addnew=0;
  if($('#custnameid').val()==''){
    var addnew=0;
  }else{
    var addnew=$('#custnameid').val();
  }
  
  var fn = $('#fn').val();
  
    var mn = $('#mn').val();
    var ln = $('#ln').val();
    var room = $('#room').val();
    var flr = $('#room').val();
    var bldg = $('#bldg').val();
    var hno = $('#hno').val();
    var strt = $('#street_number').val();
    var blk = $('#route').val();
    var subdv = $('#subdv').val();
    var mun = $('#administrative_area_level_1').val();
    var city = $('#locality').val();
  var addgg = $('#addgg').val();
    var addressid = $('#addressid').val();
    var ext = $('#ext').val();
    var branch = $('#branch').val();
    var notes = $('#notes').val();
    var company = $('#company').val();
    var brgy = $('#brgy').val();
    var zipcode = $('#postal_code').val();
    var country = $('#country').val();
  var emailaddr = $('#emailaddr').val();
  
  var landmark = $('#Landmark').val();
    $('#guest').val(ln+', ' + fn + ' ' +mn);
    $('#deladdress').val(addgg);
    $('#emailadd').val(emailaddr);
    
          
    if(phone == "" || fn == "" || ln == "" || addgg == "" || branch == ""){
      $('#errorBody').text("Please input all information needed.");
      $('#error-modal').modal('show');

    }else{
      $.ajax({
            type: 'POST',
            dataType: 'json',
            url: 'Customer/savenames',
            data:{
                  'id': id,
                  'custid':custid,
                  'phone': phone,
                  'loc': loc,
                  'fn': fn,
                  'mn': mn,
                  'ln': ln,
                  'room': room,
                  'flr': flr,
                  'bldg': bldg,
                  'hno': hno,
                  'strt': strt,
                  'blk': blk,
                  'subdv': subdv,
                  'mun': mun,
                  'city': city,
                  'addgg': addgg,
                  'addressid': addressid,
                  'ext': ext,
                  'branch': branch,
                  'notes': notes,
                  'zipcode': zipcode,
                  'country': country,
                  'addnew' :addnew,
                  'emailaddr' : emailaddr,
                  'landmark' : landmark
                 },
        success: function(data) {
          //alert("Successfully saved.");
          $('#custnameid').val(data);
          $('#custid_span').text('Customer:'+$('#fn').val()+' ID:'+$('#custnameid').val());
          
          $('#ordertaking_tab').removeClass("noclickme");
          $('#orderdetails_tab').removeClass("noclickme");
          $('#transviewer_tab').removeClass("noclickme");
          $('#transhistory_tab').removeClass("noclickme");
          $('#date-timepicker2').addClass("noclickme");
          $('#orderNote').removeClass("noclickme");
          showCustAddress();
          $('#successBody').text("Information successfully saved.");
          $('#success-modal').modal('show');
          jsonTableGenerate('OrderTaking/testmark');
        },
            error: function(data){
              $('#errorBody').text("Something went wrong.");
              $('#error-modal').modal('show');
            }
        });
    }
  } 

  function changeStoreMessage(gg){
    $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Customer/getbranchmessage',
    data:{'branch': gg},
    success: function(result) {
     $("#store_notes").html(result);
     $('#store_notes').text(result);
    },
    error: function(data){
   // alert("error");
    }
  });
  }

  function showCustAddress(){
  var id = $("#custid").val();
  if(id != ""){
     $.ajax({
          type: 'POST',
          dataType: 'json',
          url: 'Customer/searchcustaddress',
          data:{
                'id': id
               },
          success: function(data) {
              $('#result_address').html(data);
              $('#addnewadd').css('display','block');
              $('#addnewcust').css('display','none');
          },
          error: function(data){
        //    alert("error");
          }
      });
  }
}

  function locateAddress(){
    var hno = $('#hno').val();
    var blk = $('#blk').val();
    var subdv = $('#subdv').val();
    var bldg = $('#bldg').val();
    var strt = $('#strt').val();
    var brgy = $('#brgy').val();
    var mun = $('#mun').val();
    var city = $('#city').val();

    var address = hno + ' ' + blk + ' ' +  strt + ', ' + brgy + ', ' + mun + ', ' + city;
    $('#caddress').val(address);

    if(hno == "" && blk == "" &&  strt == "" &&  brgy == "" &&  mun == "" && city == ""){
       alert("Incomplete address to locate.");
    }else{
        if ($('#cboGMaps').prop('checked'))
        {
          $('#myTab a[href="#map"]').tab('show');
           search_map.click();
           var branchcode = document.getElementById('uderbranchcode').value;
           if(branchcode == "n/a" || branchcode == ""){
              $('#branch').val("NOLIST");
              document.getElementById('branch').style="font-weight:bold;color: #d43333;"
            }else{
              $('#branch').val(branchcode);
              document.getElementById('branch').style="font-weight:bold;color: rgb(39, 115, 25);";
            }
        }else{
            $.ajax({
              type: 'POST',
              dataType: 'json',
              url: 'Customer/locateaddress',
              data:{
                    'strt': strt,
                    'subdv': subdv,
                    'bldg': bldg,
                    'mun': mun,
                    'city': city
                   },
              success: function(data) {
                if(data == "NOLIST"){
                  $('#branch').val("NOLIST");
                  document.getElementById('branch').style="font-weight:bold;color: #d43333;"
                }else{
                  $('#branch').val(data[0]['code']);
                  document.getElementById('branch').style="font-weight:bold;color: rgb(39, 115, 25);";
                }
              },
              error: function(data){
            //    alert("error");
              }
            });
        }
    }
  }

  function saveComplaint(){
    var complaint = $('#result_complaints').val();
        var id = $('#id').val();

        if(id == ""){
          alert("No customer selected.");
        }else{
          if(complaint == ""){
              alert("Please select reason for calling.");
          }else{
              var phone = $('#phone').val();
              var loc = $('#loc').val();
              var fn = $('#fn').val();
              var mn = $('#mn').val();
              var ln = $('#ln').val();
              var room = $('#room').val();
              var flr = $('#flr').val();
              var bldg = $('#bldg').val();
              var hno = $('#hno').val();
              var strt = $('#strt').val();
              var blk = $('#blk').val();
              var subdv = $('#subdv').val();
              var mun = $('#mun').val();
              var city = $('#city').val();
              var custid = $('#id').val();
              var complaint_note = $('#complaints_note').val();

              $.ajax({
                  type: 'POST',
                  dataType: 'json',
                  url: 'Customer/savecomplaints',
                  data:
                      {
                        'phone': phone,
                        'loc': loc,
                        'fn': fn,
                        'mn': mn,
                        'ln': ln,
                        'room': room,
                        'floor': flr,
                        'bldg': bldg,
                        'res_no': hno,
                        'street': strt,
                        'block': blk,
                        'subdv': subdv,
                        'district':  mun,
                        'city': city,
                        'category': complaint,
                        'type': complaint,
                        'custid': custid,
                        'remarks': complaint_note
                      },
                  success: function(data){
                        alert("Saved successfully.");
                  },
                  error: function(data){
               //     alert("error");
                  }
              });
          }
        }
  }