$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#employee_li').addClass('active'); 
$('#schedule_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
	var username = $("#txtUsername").val();
	var password = $("#txtPass").val();
	var email = $("#cmbUserlevel").val();
	var first_name = $("#txtFirstname").val();
	var last_name = $("#txtLastname").val();
	var active = $("#cmbActive").val();
    var site = $('#site_url').val();
	var gender = $("#gender").val();
    $.ajax({
     url:'save_user',
     type:"post",
     data:{ id:id,
            username:username,
			password:password,
			email:email,
			first_name:first_name,
			last_name:last_name,
			active: active,
			gender:gender
			},
       success: function(data){
		   if(data == "success"){
        alert("User has been saved successfully.");
		   }else{
			   alert(data);
			   return false;
		   }
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteUser(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'user/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("User successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeUser(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'user/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("User successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}