$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#employee_li').addClass('active'); 
$('#schedule_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
	var cust_id = $("#txtCustomer").val();
	var order_id = $("#txtOrderNo option:selected").val();
	var contact = $("#txtContact").val();
	var store = $("#txtStore option:selected").val();
	var ticket_type = $("#cmbTicketType option:selected").val();
	var concern = $("#txtConcern option:selected").val();
    var remarks = $('#txtRemarks').val();
    var site = $('#site_url').val();
    $.ajax({
     url:'save_ticket',
     type:"post",
     data:{ id:id,
            cust_id: cust_id,
            order_id: order_id,
            contact_number: contact,
            store: store,
            ticket_type: ticket_type,
            concern: concern,
            remarks: remarks,
           
			},
       success: function(data){
        alert("Ticket has been saved successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteTicket(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'ticket/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Ticket successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeTicket(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'ticket/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Ticket successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}