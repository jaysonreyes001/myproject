


$(document).ready(function(){

  $('#btnAdd').click(function(e){
	  if($("#btnAdd").hasClass('disabled') == true){
		 $('#message').text('Payment Insufficient!');
									$('#alertmodal').modal('show');
		return false;
	  }
		 var del_type = $('#cmbDelMethod').find('option:selected').val();	 
  if(del_type==1){
	if($('#branch').find('option:selected').val()==undefined){
				$('#txtBranch').val('NOLIST');
			}else{
				$('#txtBranch').val($('#branch').find('option:selected').val());	
			}
  }else{
	if($('#branch2').find('option:selected').val()==undefined){
				$('#txtBranch').val('NOLIST');
			}else{
				$('#txtBranch').val($('#branch2').find('option:selected').val());	
			}
  }	  
			
  if (ordercode == ""){
		$('#message').text('Add Orders first!');
									$('#alertmodal').modal('show');
			return false;
		}
		SameCheck();

			 var id = $('#txtID').val();
		   
			 var branch = $('#txtBranch').val();
			 var brand = $('#cmbBrand').find('option:selected').val();	
			// alert(brand);
			 var order_stat = $('#order_stats').find('option:selected').val();	
			 var pay_method = $('#cmbPaymentMethod').find('option:selected').val();	
			 var del_type = $('#cmbDelMethod').find('option:selected').val();	 
			 var discount = $('#cmbDiscount').find('option:selected').val();	
			 var time_mode = $('#cmbDelTimeMode').find('option:selected').val();	
	
			 var code = $('#txtCode').val();
			// var stat = $('#txtStatus').val();
			 var stat = "";
			 var type = $('#txtType').val();
			 //var date_inserted = $('#txtCutoff').val();
			 var date_inserted = "";
			 var cfirst_name = $('#txtcFirstName').val();
			 var clast_name = $('#txtcLastName').val();
			 var ctelephone = $('#txtcTel').val().replace(/[()_-]/g, '');
			 var cmobile = $('#txtcMobile').val().replace(/[()_-]/g, '');
			 var cemail = $('#txtcEmail').val();
			// var cgoldilockscard = $('#txtcGoldi').val();
			 var cgoldilockscard = '';
			 var rfirst_name = $('#txtrFirstName').val();
			 var rlast_name = $('#txtrLastName').val();
			 var rtelephone = $('#txtrTel').val().replace(/[()_-]/g, '');
			 var rmobile = $('#txtrMobile').val().replace(/[()_-]/g, '');
			 var remail = $('#txtrEmail').val();
			 var address_type = $('#txtAddressType').val();
			 var building = $('#txtBuilding').val();
			 var city = $('#txtCity').val();
			 var number = $('#txtNumber').val();
			 var street = $('#txtStreet').val();
			 var barangay = $('#txtBarangay').val();
			 var landmark = $('#txtlandmark').val();
			 var remarks = $('#txtRemarks').val();
			 var longitude = $('#txtLong').val();
			 var latitude = $('#txtLat').val();
			 var delivery_date =  $('#txtDeliveryDate').val();
			 var delivery_charge =  $('#txtDelCh').val();
			 var method =  pay_method;
			 var discount_id =  $('#txtDiscountID').val();
			
			 var discount_amount =  $('#txtDiscountAmount').val();
			 var discount_name =  $('#txtDiscountName').val();
			 var amount =  $('#txtSubtotal').val();
			 var change_for =  $('#txtChangefor').val();
			 var change =  $('#txtChange').val();
			 var prm_code =  $('#txtPrm').val();
			 var offer =  $('#txtOffer').val();
			 var autocomplete =  $('#autocomplete').val();
			 var agenttime = $('#ahttimer').html();
			 var sectime = aht;
			if(pay_method==""){
				pay_method=0;
				method=0;
			}
			if(amount <299){
				$('#message').text('Minimum Order 300');
									$('#alertmodal').modal('show');
			
				return false;
			}
			
	
			var site = $('#site_url').val();
			if(cfirst_name == "" ){
				if(cfirst_name == "" ){
				$('#message').text('Please fill up Customer First Name');
									$('#alertmodal').modal('show');
			
				return false;
				
			}else if(clast_name == "" ){

					$('#message').text('Please fill up Customer Last Name');
									$('#alertmodal').modal('show');
			
				return false;
				
			}else if( ctelephone == ""){
				$('#message').text('Please fill up Customer Telephone');
									$('#alertmodal').modal('show');
				
				return false;
				
			}else if( cmobile == ""  ){

$('#message').text('Please fill up Customer Mobile');
									$('#alertmodal').modal('show');


				return false;
				
			}else if( rfirst_name == "" ){

$('#message').text('Please fill up Recipient First Name');
									$('#alertmodal').modal('show');


			
				return false;
				
			}else if( rlast_name == "" ){


$('#message').text('Please fill up Recipient Last Name');
									$('#alertmodal').modal('show');

				
				return false;
				
			}else if( rtelephone == "" ){

$('#message').text('Please fill up Recipient Telephone');
									$('#alertmodal').modal('show');


	
				return false;
				

			}else if( rmobile == "" ){

				$('#message').text('Please fill up Recipient mobile');
									$('#alertmodal').modal('show');
			
				return false;
				
			}else if( longitude == ""){

$('#message').text('Please locate to fill longitude');
									$('#alertmodal').modal('show');

				return false;
				
			}else if(  latitude == "" ){
$('#message').text('Please locate to fill latitude');
									$('#alertmodal').modal('show');

			
				return false;
				
			}else if( autocomplete == ""){

$('#message').text('Please fill up autocomplete');
									$('#alertmodal').modal('show');


			
				return false;
				
			}else if( (branch =="" || branch =="NOLIST") ){

$('#message').text('Please fill up branch');
									$('#alertmodal').modal('show');

				
				return false;
			}
			$.ajax({
			 url:'edit_status',
			 type:"post",
			 data:{ id:id,
					code:code,
					//stat:stat,
					type:type,
					brand:brand,
					//date_inserted:date_inserted,
					cfirst_name:cfirst_name,
					clast_name:clast_name,
					ctelephone:ctelephone,
					cmobile:cmobile,
					cemail:cemail,
					//cgoldilockscard:cgoldilockscard,
					rfirst_name:rfirst_name,
					rlast_name:rlast_name,
					rtelephone:rtelephone,
					rmobile:rmobile,
					remail:remail,
					address_type:address_type,
					building:building,
					city:city,
					number:number,
					street:street,
					barangay:barangay,
					landmark:landmark,
					remarks:remarks,
					longitude:longitude,
					latitude:latitude,
					branch: branch,
					delivery_date :  delivery_date,
					delivery_charge :  delivery_charge,
					method :  pay_method,
					amount : amount,
					change_for :  change_for,
					change :  change,
					prm_code :  prm_code,
					offer :  offer,
					autocomplete :  autocomplete,
					del_type :  del_type,
					discount_id :  discount_id,
					discount :  discount,
					discount_name :  discount_name,
					discount_amount :  discount_amount,
					aht :  agenttime,
					aht_sec :  sectime,
					time_mode :  time_mode,
					
					order_stat: order_stat,
				   },
			   success: function(data){
				$('#message').text('Order has been routed successfully.');
									$('#alertmodal').modal('show');
				//setTimeout(function(){window.location.href=site;}, 1000);
				clearData();
				stopaht_timer();
			  }
			});
	
  });
 $('#btnWait').click(function(e){
		 var del_type = $('#cmbDelMethod').find('option:selected').val();	 
  if(del_type==1){
	if($('#branch').find('option:selected').val()==undefined){
				$('#txtBranch').val('NOLIST');
			}else{
				$('#txtBranch').val($('#branch').find('option:selected').val());	
			}
  }else{
	if($('#branch2').find('option:selected').val()==undefined){
				$('#txtBranch').val('NOLIST');
			}else{
				$('#txtBranch').val($('#branch2').find('option:selected').val());	
			}
  }	  
			
  if (ordercode == ""){
		$('#message').text('Add Orders first!');
									$('#alertmodal').modal('show');
			return false;
		}
		SameCheck();

			 var id = $('#txtID').val();
		   
			 var branch = $('#txtBranch').val();
			 var brand = $('#cmbBrand').find('option:selected').val();	
			// alert(brand);
			 var order_stat = $('#order_stats').find('option:selected').val();	
			 var pay_method = $('#cmbPaymentMethod').find('option:selected').val();	
			 var del_type = $('#cmbDelMethod').find('option:selected').val();	 
			 var discount = $('#cmbDiscount').find('option:selected').val();	
	
			 var code = $('#txtCode').val();
			// var stat = $('#txtStatus').val();
			 var stat = "";
			 var type = $('#txtType').val();
			 //var date_inserted = $('#txtCutoff').val();
			 var date_inserted = "";
			 var cfirst_name = $('#txtcFirstName').val();
			 var clast_name = $('#txtcLastName').val();
			 var ctelephone = $('#txtcTel').val();
			 var cmobile = $('#txtcMobile').val();
			 var cemail = $('#txtcEmail').val();
			// var cgoldilockscard = $('#txtcGoldi').val();
			 var cgoldilockscard = '';
			 var rfirst_name = $('#txtrFirstName').val();
			 var rlast_name = $('#txtrLastName').val();
			 var rtelephone = $('#txtrTel').val();
			 var rmobile = $('#txtrMobile').val();
			 var remail = $('#txtrEmail').val();
			 var address_type = $('#txtAddressType').val();
			 var building = $('#txtBuilding').val();
			 var city = $('#txtCity').val();
			 var number = $('#txtNumber').val();
			 var street = $('#txtStreet').val();
			 var barangay = $('#txtBarangay').val();
			 var landmark = $('#txtlandmark').val();
			 var remarks = $('#txtRemarks').val();
			 var longitude = $('#txtLong').val();
			 var latitude = $('#txtLat').val();
			 var delivery_date =  $('#txtDeliveryDate').val();
			 var delivery_charge =  $('#txtDelCh').val();
			 var method =  pay_method;
			 var discount_id =  $('#txtDiscountID').val();
			
			 var discount_amount =  $('#txtDiscountAmount').val();
			 var discount_name =  $('#txtDiscountName').val();
			 var amount =  $('#txtSubtotal').val();
			 var change_for =  $('#txtChangefor').val();
			 var change =  $('#txtChange').val();
			 var prm_code =  $('#txtPrm').val();
			 var offer =  $('#txtOffer').val();
			 var autocomplete =  $('#autocomplete').val();
			 var agenttime = $('#ahttimer').html();
			 var sectime = aht;
			if(pay_method==""){
				pay_method=0;
				method=0;
			}
			if(amount <299){
					$('#message').text('Minimum Order 300');
									$('#alertmodal').modal('show');
				
				return false;
			}
			
	
			var site = $('#site_url').val();
			if(cfirst_name == "" ){

				$('#message').text('Please fill up Customer First Name');
									$('#alertmodal').modal('show');
				
				return false;
				
			}else if(clast_name == "" ){
				$('#message').text('Please fill up Customer Last Name');
									$('#alertmodal').modal('show');
				
				return false;
				
			}else if( ctelephone == ""){
				$('#message').text('Please fill up Customer Telephone');
									$('#alertmodal').modal('show');
			
				return false;
				
			}else if( cmobile == ""  ){
				$('#message').text('Please fill up Customer Mobile');
									$('#alertmodal').modal('show');
				
				return false;
				
			}else if( rfirst_name == "" ){
				$('#message').text('Please fill up Recipient First Name');
									$('#alertmodal').modal('show');
				
				return false;
				
			}else if( rlast_name == "" ){
				$('#message').text('Please fill up Recipient Last Name');
									$('#alertmodal').modal('show');
			
				return false;
				
			}else if( rtelephone == "" ){
				$('#message').text('Please fill up Recipient Telephone');
									$('#alertmodal').modal('show');
		
				return false;
				
			}else if( rmobile == "" ){

			$('#message').text('Please fill up Recipient mobile');
									$('#alertmodal').modal('show');

			
				return false;
				
			}else if( longitude == ""){

			$('#message').text('Please locate to fill longitude');
									$('#alertmodal').modal('show');

			
				return false;
				
			}else if(  latitude == "" ){

			$('#message').text('Please locate to fill latitude');
									$('#alertmodal').modal('show');

				return false;
				
			}else if( accept_reason == ""){

			$('#message').text('Please fill up Reason');
									$('#alertmodal').modal('show');


				return false;
			}
			$.ajax({
			 url:'edit_status2',
			 type:"post",
			 data:{ id:id,
					code:code,
					//stat:stat,
					type:type,
					brand:brand,
					//date_inserted:date_inserted,
					cfirst_name:cfirst_name,
					clast_name:clast_name,
					ctelephone:ctelephone,
					cmobile:cmobile,
					cemail:cemail,
					//cgoldilockscard:cgoldilockscard,
					rfirst_name:rfirst_name,
					rlast_name:rlast_name,
					rtelephone:rtelephone,
					rmobile:rmobile,
					remail:remail,
					address_type:address_type,
					building:building,
					city:city,
					number:number,
					street:street,
					barangay:barangay,
					landmark:landmark,
					remarks:remarks,
					longitude:longitude,
					latitude:latitude,
					branch: branch,
					delivery_date :  delivery_date,
					delivery_charge :  delivery_charge,
					method :  pay_method,
					amount : amount,
					change_for :  change_for,
					change :  change,
					prm_code :  prm_code,
					offer :  offer,
					autocomplete :  autocomplete,
					del_type :  del_type,
					discount_id :  discount_id,
					discount :  discount,
					discount_name :  discount_name,
					discount_amount :  discount_amount,
					aht :  agenttime,
					aht_sec :  sectime,
					
					order_stat: order_stat,
				   },
			   success: function(data){
			$('#message').text('Order has been saved successfully.');
									$('#alertmodal').modal('show');
				//setTimeout(function(){window.location.href=site;}, 1000);
				clearData();
				stopaht_timer();
			  }
			});
	
  });
  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});
function clearData(){
			$('#txtCustid').val('');
			$('#txtAddrid').val('');
			$('#txtID').val('');
			$('#txtBranch').val('');
			$('#order_stats').find('option:selected').val('');	
			$('#cmbPaymentMethod').find('option:selected').val('');	
			$('#txtCode').val('');
			$('#txtcFirstName').val('');
			 $('#txtcLastName').val('');
			$('#txtcTel').val('');
			$('#txtcMobile').val('');
			$('#txtcEmail').val('');
			$('#txtrFirstName').val('');
			$('#txtrLastName').val('');
			$('#txtrTel').val('');
			$('#txtrMobile').val('');
			$('#txtrEmail').val('');
			$('#txtAddressType').val('');
			$('#txtBuilding').val('');
			$('#txtCity').val('');
			$('#txtNumber').val('');
			$('#txtStreet').val('');
			$('#txtBarangay').val('');
			$('#txtlandmark').val('');
			$('#txtRemarks').val('');
			$('#txtLong').val('');
			 $('#txtLat').val('');
			$('#txtDeliveryDate').val('');
			 $('#txtDelCh').val('');
			$('#txtSubtotal').val('');
			$('#txtChangefor').val('');
			$('#txtPrm').val('');
			$('#txtOffer').val('');
			$('#autocomplete').val('');
			$('#autocomplete').val('');
			$('#menu-button').html('');
			$('#txtPaymentMethod').val('');
			$('#txtDiscountID').val('');
			$('#txtDiscountID').val('');
			$('#txtDiscountAmount').val('');
			$('#txtDiscountName').val('');
			$("#sameCheck").prop("checked", false);
			$("#modal-summary").modal('hide');
			ordercode = "";
				orderid = "";
				totprice = 0;
			$("#branch").html("<option value='NOLIST'>NOLIST</option>");
				//$('#formSite').trigger('reset');
				//get_neworders();
				$('#order-body').html('');
				//$('#txtID').val(orderid);
				//$('#txtCode').val(ordercode);
				//get_orders(ordercode);
				//get_menu(ordercode);
}
