$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#employee_li').addClass('active'); 
$('#schedule_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
	var type = $("#cmbType").val();
	var name = $("#txtName").val();
	var active = $("#cmbActive").val();
    var site = $('#site_url').val();
    $.ajax({
     url:'save_tickettype',
     type:"post",
     data:{ id:id,
            type:type,
			name:name,
			active: active
			},
       success: function(data){
		   if(data == "success"){
        alert("Ticket Type has been saved successfully.");
		   }else{
			   alert(data);
			   return false;
		   }
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteTickettype(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'tickettype/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Ticket Type successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeTickettype(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'tickettype/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Ticket Type successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}