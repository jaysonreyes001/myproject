
$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
   
    var branch = $('#txtBranch').val();
	 var order_stat = $('#order_stats').find('option:selected').val();	

    var site = $('#site_url').val();
    $.ajax({
     url:'realtime/edit_status',
     type:"post",
     data:{ id:id,
        
            branch: branch,
			
			order_stat: order_stat,
           },
       success: function(data){
        alert("Order set to "+ order_stat +". ");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});
