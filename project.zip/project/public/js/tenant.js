$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#tenant_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
    var name = $('#txtName').val();
    var contact = $('#txtContact').val();
    var office = $('#txtOffice').val();
    var residence = $('#txtResidence').val();
    var phone = $('#txtPhone').val();
    var mobile = $('#txtMobile').val();
    var email = $('#txtEmail').val();
    var category = $('#txtCategory').val();
    var class1 = $('#txtClass').val();
    var remarks = $('#txtRemarks').val();
    var site = $('#site_url').val();
    $.ajax({
     url:'save_tenant',
     type:"post",
     data:{ id:id,
            name: name,
            contact: contact,
            office: office,
            residence: residence,
            phone: phone,
            mobile: mobile,
            email: email,
            category: category,
            class1: class1,
            remarks: remarks},
       success: function(data){
        alert("Tenant has been saved successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteTenant(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'tenant/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Tenant successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeTenant(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'tenant/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Tenant successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}