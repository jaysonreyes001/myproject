var polygon = [];
	var map;
    $(function(){
		
		google.maps.Polygon.prototype.Contains = function (point) {
            // ray casting alogrithm http://rosettacode.org/wiki/Ray-casting_algorithm
            var crossings = 0,
            path = this.getPath();
			//alert("sands");
            // for each edge
            for (var i = 0; i < path.getLength(); i++) {
                var a = path.getAt(i),
                j = i + 1;
                if (j >= path.getLength()) {
                    j = 0;
                }
                var b = path.getAt(j);
                if (rayCrossesSegment(point, a, b)) {
                    crossings++;
                }
            }

            // odd number of crossings?
            return (crossings % 2 == 1);

            function rayCrossesSegment(point, a, b) {
                var px = point.lng(),
                py = point.lat(),
                ax = a.lng(),
                ay = a.lat(),
                bx = b.lng(),
                by = b.lat();
                if (ay > by) {
                    ax = b.lng();
                    ay = b.lat();
                    bx = a.lng();
                    by = a.lat();
                }
                if (py == ay || py == by) py += 0.00000001;
                if ((py > by || py < ay) || (px > Math.max(ax, bx))) return false;
                if (px < Math.min(ax, bx)) return true;

                var red = (ax != bx) ? ((by - ay) / (bx - ax)) : Infinity;
                var blue = (ax != px) ? ((py - ay) / (px - ax)) : Infinity;
                return (blue >= red);
            }
        };
		
         // create map         
		var manilaCenter=new google.maps.LatLng(14.608668,121.042187);
		var myOptions = {
		  	zoom: 12,
		  	center: manilaCenter,
		  	mapTypeId: google.maps.MapTypeId.ROADMAP
		  }
		map = new google.maps.Map(document.getElementById('main-map'), myOptions);
		
		var creator = new PolygonCreator(map);
         // attached a polygon creator drawer to the map
		 //show address 
		var latsgn = 1;
		var lgsgn = 1;
		var cmarker = null;
		var cmarkers = new Array();
		var posset = 0;
		var ls='';
		var lm='';
		var ld='';
		var lgs='';
		var lgm='';
		var lgd='';
		var mrks = {mvcMarkers: new google.maps.MVCArray()};
		var iw;
		var drag=false;
		
		function setAllMap(map) {
		  for (var cx = 0; cx < cmarkers.length; cx++) {
			cmarkers[cx].setMap(map);			
		  }
		}
		function computepos (point)
		{
			var latA = Math.abs(Math.round(point.lat() * 1000000.));
			var lonA = Math.abs(Math.round(point.lng() * 1000000.));
			if(point.lat() < 0)
			{
				var ls = '-' + Math.floor((latA / 1000000)).toString();
			}
			else
			{
				var ls = Math.floor((latA / 1000000)).toString();
			}
			var lm = Math.floor(((latA/1000000) - Math.floor(latA/1000000)) * 60).toString();
			var ld = ( Math.floor(((((latA/1000000) - Math.floor(latA/1000000)) * 60) - Math.floor(((latA/1000000) - Math.floor(latA/1000000)) * 60)) * 100000) *60/100000 ).toString();
			if(point.lng() < 0)
			{
			  var lgs = '-' + Math.floor((lonA / 1000000)).toString();
			}
			else
			{
				var lgs = Math.floor((lonA / 1000000)).toString();
			}
			var lgm = Math.floor(((lonA/1000000) - Math.floor(lonA/1000000)) * 60).toString();
			var lgd = ( Math.floor(((((lonA/1000000) - Math.floor(lonA/1000000)) * 60) - Math.floor(((lonA/1000000) - Math.floor(lonA/1000000)) * 60)) * 100000) *60/100000 ).toString();
			document.getElementById("latbox").value=point.lat().toFixed(6);			
			document.getElementById("lonbox").value=point.lng().toFixed(6);
			
		}
		
		function getCallerLoc()
		{
			var latitude = document.getElementById('latbox').value;
			var longitude = document.getElementById('lonbox').value;
			var myPoint = new google.maps.LatLng(latitude, longitude);
			document.getElementById('uderbranchcode').value = "n/a";
			//alert(myPoint);
			
			for (var lx = 0; lx < polygon.length; lx++) {
				//polygon[cx].setMap(map);			
				//alert(polygon[lx].objInfo);
				//alert(polygon[lx].html);
				if (polygon[lx] == null) {
					alert("No Polygon");
				}
				else
				{
					if (polygon[lx].Contains(myPoint)){
						//alert(polygon[lx].html);
						//uderbranchcode
						document.getElementById('uderbranchcode').value = polygon[lx].html;
						break;
					}
				}
			  }
		}
		$('#search').click(function(){ 
				setAllMap(null);
		 		var x=document.getElementById("caddress").value
				var ll = new google.maps.LatLng(20.0, -10.0);
				var cimage = {
							url: '<?php echo base_url('public'); ?>/images/caller.png'
						  };
				map.setTilt(0);
				map.panTo(ll);

				cmarker=new google.maps.Marker({position:ll,map:map,icon:cimage,draggable:true,title:x});   
				cmarkers.push(cmarker);
				google.maps.event.addListener(cmarker, 'click', function(mll) {
				//gC(mll.latLng);
				var html= "<div style='color:#000;background-color:#fff;padding:5px;width:150px;'><p>Latitude - Longitude:<br />" + String(mll.latLng.toUrlValue()) + "<br /><br />Lat: " + ls +  "&#176; " + lm +  "&#39; "  + ld + "&#34;<br />Long: " + lgs +  "&#176; " + lgm +  "&#39; " + lgd + "&#34;</p></div>";
				iw = new google.maps.InfoWindow({content:html});
				iw.open(map,cmarker);
				});
				
				google.maps.event.addListener(cmarker, 'dragstart', function() {if (iw){iw.close();}});
				google.maps.event.addListener(cmarker, 'dragend', function(event) {
				posset = 1;
				//if (map.getZoom() < 10){map.setZoom(10);}
				map.setCenter(event.latLng);
				computepos(event.latLng);
				getCallerLoc();
				drag=true;
				setTimeout(function(){drag=false;},250);
				});
				google.maps.event.addListener(map, 'click', function(event) {
					if (drag){return;}
					posset = 1;
					fc(event.latLng) ;
					if (map.getZoom() < 10){map.setZoom(10);}
					map.panTo(event.latLng);
					computepos(event.latLng);
					getCallerLoc();
					
					});
				
				var geocoder = new google.maps.Geocoder();
				geocoder.geocode( { 'address': x}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					map.setCenter(results[0].geometry.location);
					map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
					if (map.getZoom() < 12){map.setZoom(12);}else{}
						cmarker.setPosition(results[0].geometry.location);
						posset = 1;
						computepos(results[0].geometry.location);
						//alert(results[0].geometry.location);
						getCallerLoc();
				  
					} else {
						alert("Geocode was not successful for the following reason: " + status);
					}
				});
		 });
		 
		 //delete
		 $('#delete').click(function(){ 
		 		var x=document.getElementById("branchcode").value;
				//alert(x);
				if (x==null || x=="")
				  {
				  alert("Please set branch code!");
				  return false;
				  }
				else{
					 $.ajax({
						data: 'branchcode=' + x,
						url: 'delete_branch_map.php',
						method: 'POST', // or GET
						success: function(msg) {
							alert(msg);
							location.reload();
						}
					});
				}
		 });
         //show paths
		 $('#showData').click(function(){ 
		 		$('#dataPanel').empty();
		 		if(null==creator.showData()){
		 			$('#dataPanel').append('Please create a polygon first!');
		 		}else{
		 			$('#dataPanel').append(creator.showData());
					$('#pathtext').val(creator.showData());
					
		 		}
		 });
        //reset
		 $('#reset').click(function(){ 
		 		creator.destroy();
		 		creator=null;		 		
		 		creator=new PolygonCreator(map);
		 });	
		//delete
         // set polygon data to the form hidden field
         $('#map-form').submit(function () {
            $('#map-coords').val(creator.showData());
			
         });
		 
        var spge = '<?php if(isset($spge)) {echo $spge;}else{echo "";} ?>';						 
		if (spge!=null || spge!="")
		{
		var polygonCoords = [];
		var obj = [];
		var marker;
		var markers = new Array();
		var pmarker;
		var pmarkers = new Array();
		var locations = [];
		var infowindow;

		var loc;
		var temp=spge.split('|'); 
		//alert(temp.length);
		for (var a = 0; a < temp.length; a++){
			if(temp[a]!=''){
				var tempb=temp[a].split(';');
				if(tempb[0]!=''){
					//alert(tempb[0]);
					var carray = tempb[0].replace(')','').replace('(','').split('_');
					if(carray.length>0){
						
						for (var b = 0; b < carray.length; b++){
							var coords = carray[b].replace(')','').replace('(','');
							var pos = coords.split(",");
							//alert(pos[0] + "#" + pos[1]);
							var loc = new google.maps.LatLng(pos[0], pos[1]);
							polygonCoords.push(loc);
						}	
						polygon[a] = new google.maps.Polygon({
							html: tempb[2],
							indexID: a,
							paths: polygonCoords,
							strokeColor: tempb[1],
							strokeOpacity: 0.8,
							strokeWeight: 2,
							fillColor: tempb[1],
							fillOpacity: 0.35
						   
						});
						//alert(tempb[2]);
						obj[a] = {
							'id':tempb[2]
						};
						polygon[a].objInfo = obj[a];
						
						var bounds = new google.maps.LatLngBounds();
						var i;	
						for (i = 0; i < polygonCoords.length; i++) {
							  bounds.extend(polygonCoords[i]);
							}
						
						infowindow = new google.maps.InfoWindow({
							  content: tempb[2]
						  });
						  
						var image = {
							url: '<?php echo base_url('public'); ?>/images/jollibee_03.png'
						  };
						  
						marker = new google.maps.Marker({
							  position: bounds.getCenter(),
							  map: map,
							  icon: image,
							  title: tempb[2]
						  });
						markers.push(marker);
						location[a] = tempb[2];
						//alert(tempb[2]);
						google.maps.event.addListener(marker, 'click', (function(marker, a) {
							return function() {
							  infowindow.setContent(location[a]);
							  infowindow.open(map, marker);
							}
						  })(marker, a));
						pmarker = new MarkerWithLabel({
						  position: bounds.getCenter(),
						  draggable: false,
						  raiseOnDrag: false,
						  map: map,
						  labelContent: location[a],
						  labelAnchor: new google.maps.Point(30, 20),
						  labelClass: "labels", 
						  labelStyle: {opacity: 1.0},
						  icon: "http://placehold.it/1x1",
						  visible: false
						 });
						pmarkers.push(pmarker);
						var poly = polygon[a];
						google.maps.event.addListener(polygon[a], 'mousemove', (function(pmarker, a) {
							return function(event) {
							  pmarker.setPosition(event.latLng);
							  pmarker.setVisible(true);
							}
						  })(pmarker, a));
						  google.maps.event.addListener(polygon[a], 'mouseout', (function(pmarker, a) {
							return function(event) {
							 pmarker.setVisible(false);
							}
						  })(pmarker, a));		
						google.maps.event.addListener(polygon[a], 'click', (function(pmarker, a) {
							return function(event) {
							}
						  })(pmarker, a));
						polygon[a].setMap(map);
						polygonCoords = [];						
					}				
				}
			}
		}
	}
	
		
    });
	function validateForm()
		{
			var x;
			x=document.getElementById("pathtext").value;
			//alert(x);
			if (x==null || x=="")
			  {
			  alert("Please show paths first!");
			  return false;
			  }
			 x=document.getElementById("color").value;
			if (x==null || x=="")
			  {
			  alert("Please set polygon color!");
			  return false;
			  }
			x=document.getElementById("branchcode").value;
			if (x==null || x=="")
			  {
			  alert("Please set branch code!");
			  return false;
			  }
			  
			  
		}
	function validateDelete()
	{
		x=document.getElementById("branchcode").value;
			if (x==null || x=="")
			  {
			  alert("Please set branch code to be deleted!");
			  return false;
			  }
	}
	