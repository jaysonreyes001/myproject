var chartbar;
var data = '[{"branch":"All","counts":"3","total":"2545.00"}]';
var chartData = JSON.parse(data);

AmCharts.ready(function () {
    // SERIAL CHART
    chartbar = new AmCharts.AmSerialChart();

    chartbar.dataProvider = chartData;
    chartbar.categoryField = "branch";
    chartbar.startDuration = 1;

    chartbar.handDrawn = true;
    chartbar.handDrawnScatter = 3;

    // AXES
    // category
    var categoryAxis = chartbar.categoryAxis;
    categoryAxis.gridPosition = "start";

    // value
    var valueAxis = new AmCharts.ValueAxis();
    valueAxis.axisAlpha = 0;
    chartbar.addValueAxis(valueAxis);
    var valueAxis2 = new AmCharts.ValueAxis();
    valueAxis2.axisAlpha = 0;
    valueAxis2.gridThickness=0;
    valueAxis2.position="right";
    chartbar.addValueAxis(valueAxis2);

    // GRAPHS
    // column graph
    var graph1 = new AmCharts.AmGraph();
    graph1.type = "column";
    graph1.title = "Total";
    graph1.lineColor = "#a668d5";
    graph1.valueField = "total";
    graph1.lineAlpha = 1;
    graph1.fillAlphas = 1;
    graph1.dashLengthField = "dashLengthColumn";
    graph1.alphaField = "alpha";
    graph1.balloonText = "<span style='font-size:13px;'>[[title]] in [[category]]:<b>[[value]]</b> [[additional]]</span>";
    chartbar.addGraph(graph1);

    // line
    var graph2 = new AmCharts.AmGraph();
    graph2.type = "line";
    graph2.title = "TC";
    graph2.lineColor = "#fcd202";
    graph2.valueField = "tc";
    graph2.valueAxis=valueAxis2;
    graph2.lineThickness = 3;
    graph2.bullet = "round";
    graph2.bulletBorderThickness = 3;
    graph2.bulletBorderColor = "#fcd202";
    graph2.bulletBorderAlpha = 1;
    graph2.bulletColor = "#ffffff";
    graph2.dashLengthField = "dashLengthLine";
    graph2.balloonText = "<span style='font-size:13px;'>[[title]] in [[category]]:<b>[[value]]</b> [[additional]]</span>";
    chartbar.addGraph(graph2);

    // LEGEND
    var legend = new AmCharts.AmLegend();
    legend.useGraphSettings = true;
    chartbar.addLegend(legend);
    chartbar.export = AmCharts.exportCFG;

    // WRITE
    chartbar.write("chartdiv10");
});

function LoadNewDataFromDIV(data)
{
  //This function attempts to use a string of objects to pass to the dataprovider setting
  var ChartData = data;
  var tojson = JSON.parse(ChartData);
  chartbar.dataProvider = tojson;
  chartbar.validateData();
}