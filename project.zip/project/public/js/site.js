$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#site_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
    var name = $('#txtName').val();
    var location = $('#txtLocation').val();
    var area = $('#txtArea').val();
    var duration = $('#txtContractDuration').val();
    var cutoff = $('#txtCutoff').val();
    var rent = $('#txtRent').val();
    var stall_count = $('#txtStallCount').val();
    var stall_rent = $('#txtStallRent').val();
    var deposit = $('#txtDeposit').val();
    var advance = $('#txtAdvance').val();
    var bank_name = $('#txtBankName').val();
    var bank_branch = $('#txtBankBranch').val();
    var account_no = $('#txtAccountNo').val();
    var remarks = $('#txtRemarks').val();
    var site = $('#site_url').val();
    $.ajax({
     url:'save_site',
     type:"post",
     data:{ id:id,
            name: name,
            location: location,
            area: area,
            duration: duration,
            cutoff: cutoff,
            rent: rent,
            stall_count: stall_count,
            stall_rent: stall_rent,
            deposit: deposit,
            advance: advance,
            bank_name: bank_name,
            bank_branch: bank_branch,
            account_no: account_no,
            remarks: remarks},
       success: function(data){
        alert("Site has been saved successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteSite(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'site/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Site successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeSite(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'site/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Site successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}