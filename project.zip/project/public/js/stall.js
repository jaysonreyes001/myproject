$('#dashboard_li').removeClass('active');
$('#maintenance_li').addClass('active'); 
$('#stall_li').addClass('active'); 

$(document).ready(function(){

  $('#btnAdd').click(function(e){
    var id = $('#txtID').val();
    var name = $('#txtName').val();
    var stall_no = $('#txtStallNo').val();
    var contact = $('#txtContact').val();
    var office = $('#txtOffice').val();
    var monthly = $('#txtMonthly').val();
    var deposit = $('#txtDeposit').val();
    var advance = $('#txtAdvance').val();
    var area = $('#txtArea').val();
    var location = $('#txtLocation').val();
    var rent = $('#txtRent').val();
    var cutoff = $('#txtCutoff').val();
    var contract = $('#txtContract').val();
    var remarks = $('#txtRemarks').val();
    var site = $('#site_url').val();
    $.ajax({
     url:'save_stall',
     type:"post",
     data:{ id:id,
            name: name,
            stall_no: stall_no,
            contact: contact,
            office: office,
            monthly: monthly,
            deposit: deposit,
            advance: advance,
            area: area,
            location: location,
            rent: rent,
            cutoff: cutoff,
            contract: contract,
            remarks: remarks},
       success: function(data){
        alert("Stall has been saved successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});

function deleteStall(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'stall/edit_status',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Stall successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeStall(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'stall/edit_status',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Stall successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}