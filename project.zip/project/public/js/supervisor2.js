$(document).ready(function() { 

  
    var myTable = 
    $('.dynamic-table')
    .DataTable({
      bAutoWidth: false,
      "aoColumns": [
      { "bSortable": false },
      null, null,null, null, null,
      { "bSortable": false }
      ],
      "aaSorting": [],
      select: {
        style: 'multi'
      }
    });

 

  $(".date-picker").datepicker('setDate', new Date());

  $('#type_reports').change( function (){
    var type = $('#type_reports').val();

    if (type == "4"){

     $('#exportReportsss').css('display','block');
     $('#bar_result').css('display','none');
     $('#report_result').css('display','block');

      $("#date_to_from").css("display","none");
      $("#interval_sales_div").css("display","block");
      $("#bar_graph_div").css("display","none");
    }else if (type == "5"){
     $('#exportReportsss').css('display','none');

     $('#bar_result').css('display','block');
     $('#report_result').css('display','none');

      $("#date_to_from").css("display","none");
      $("#interval_sales_div").css("display","none");
      $("#bar_graph_div").css("display","block");
    }else{
     $('#exportReportsss').css('display','block');
     $('#bar_result').css('display','none');
     $('#report_result').css('display','block');

      $("#date_to_from").css("display","block");
      $("#interval_sales_div").css("display","none");
      $("#bar_graph_div").css("display","none");
    }
  });

  $('#interval_type').change( function (){
    var type = $('#interval_type').val();

    if (type == "1"){
      $("#interval_type_hourly").css("display","block");
      $("#interval_type_daily").css("display","none");
      $("#interval_type_weekly").css("display","none");
    }else if (type == "2"){
      $("#interval_type_hourly").css("display","none");
      $("#interval_type_daily").css("display","block");
      $("#interval_type_weekly").css("display","none");
    }else if (type == "3"){
      $("#interval_type_hourly").css("display","none");
      $("#interval_type_daily").css("display","none");
      $("#interval_type_weekly").css("display","block");
    }
  });

  
  $('#bar_type').change( function (){
    var type = $('#bar_type').val();

    if (type == "1"){
      $("#bar_daily").css("display","block");
      $("#bar_weekly").css("display","none");
    }else if (type == "2"){
      $("#bar_daily").css("display","none");
      $("#bar_weekly").css("display","block");
    }else if (type == "3"){
      $("#bar_daily").css("display","none");
      $("#bar_weekly").css("display","none");
    }
  });

  $("#cmbGraphs").change(function() {
  var graph = $("#cmbGraphs").val();
  if (graph == "1"){
    lineChart2();
    $("#daily_count").css("display","block");
    $("#daily_order").css("display","none");
    $("#weekly_total").css("display","none");
    $("#top_ten").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#monthly_total_sales").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "2"){
    pieChart();
    $("#daily_order").css("display","block");
    $("#daily_count").css("display","none");
    $("#weekly_total").css("display","none");
    $("#top_ten").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#monthly_total_sales").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "3"){
    lineChart();
    $("#weekly_total").css("display","block");
    $("#daily_count").css("display","none");
    $("#daily_order").css("display","none");
    $("#top_ten").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#monthly_total_sales").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "4"){
    barGraph();
    $("#top_ten").css("display","block");
    $("#weekly_total").css("display","none");
    $("#daily_count").css("display","none");
    $("#daily_order").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#monthly_total_sales").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "5"){
    lineChart5();
    $("#weekly_total_delivery").css("display","block");
    $("#weekly_total").css("display","none");
    $("#daily_count").css("display","none");
    $("#daily_order").css("display","none");
    $("#top_ten").css("display","none");
    $("#monthly_total_sales").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "6"){
    lineChart4();
    $("#monthly_total_sales").css("display","block");
    $("#weekly_total").css("display","none");
    $("#daily_count").css("display","none");
    $("#daily_order").css("display","none");
    $("#top_ten").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#daily_number").css("display","none");
  }else if (graph == "7"){
    lineChart3();
    $("#daily_number").css("display","block");
    $("#weekly_total").css("display","none");
    $("#daily_count").css("display","none");
    $("#daily_order").css("display","none");
    $("#top_ten").css("display","none");
    $("#weekly_total_delivery").css("display","none");
    $("#monthly_total_sales").css("display","none");
  }
});


  var last_id = localStorage.getItem('tab_id');
  if (last_id) {
    $('.supervisor-tab').removeClass('active');
    $('.supervisor-tab1').removeClass('in active');
    $("#" + last_id).addClass('active');
    if(last_id == 'tabPending'){
      loadTableOrders('2','#pendingtable');
    }else if (last_id == 'tabMisrouted'){
      loadTableOrders('3','#misroutedtable');
    }else if (last_id == 'tabConfirm'){
      loadTableOrders('4','#confirmtable');
    }else if (last_id == 'tabVoided'){
      loadTableOrders('5','#voidedtable');
    }else if (last_id == 'tabFollowUp'){
      loadTableOrders('6','#fuptable');
    }else if (last_id == 'tabBranchStat'){
        //loadTableOrders('3','#misroutedtable');
      }else if (last_id == 'tabBranchEdit'){
        //loadTableOrders('3','#misroutedtable');
      }else if (last_id == 'tabOnline'){
        loadTableOrders('1','#alltables');
      }else if (last_id == 'tabHitRate'){
        loadHitRateTable('9','#hitratetable');
      }else if (last_id == 'tabPending1'){
        loadTableOrders('10','#pending1table');
      }else if (last_id == 'tabStoreMessage'){
        loadStoreMessage('11','#storemessagetable');
      }
      $("." + last_id).addClass('in active');
    }

    $('.supervisor-tab').click(function() {
      var tab_id = $(this).attr('id');
      localStorage.setItem('tab_id', tab_id);
    });

  });

function loadTableOrders(num, table){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/loadTable',
    data:{'num': num},
    success: function(data) {
      $(table).html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
    //  alert("error");
    }
  });
}


function exportToExcel(){

  var is_refreshed = $("#is_refreshed").val();
  var branch = $("#cmbBranches1").val();
  var date = $("#id-date-picker-hitrate").val();
  var date1 = $("#id-date-picker-hitrate1").val();

  if (is_refreshed == 0){
    $("#row_date").val(date);
    $("#row_date1").val(date1);
    $("#row_branch").val(branch);
  }else{
    $("#row_date").val("");
    $("#row_date1").val("");
    $("#row_branch").val("");
  }
    document.getElementById('export').click();
}



function exportToExcelOnline(){
  var branch = $("#cmbBranches").val();
  var date = $("#id-date-picker-online").val();
  date = date.split("-");
  date = date[2] + "-" + date[1] + "-" + date[0];
  $("#row_branch_online").val(branch);
  $("#date_online").val(date);
  document.getElementById('export_online').click();
}

function exportToExcelReport(){
  var type = $("#type_reports").val();

  if (type == 3){
    $("#type_").val($("#type_reports").val());
    $("#branchid_").val($("#branchid_reports").val());
    $("#date1").val($("#date1_reports").val());
    $("#date2").val($("#date2_reports").val());
    document.getElementById('export_report_').click();
  }else if (type == 2){
    $("#type_").val($("#type_reports").val());
    $("#branchid_1").val($("#branchid_reports").val());
    $("#date1_1").val($("#date1_reports").val());
    $("#date2_1").val($("#date2_reports").val());
    document.getElementById('export_report2_').click();
  }else if (type == 1){
    $("#branchid_2").val($("#branchid_reports").val());
    $("#date1_2").val($("#date1_reports").val());
    $("#date2_2").val($("#date2_reports").val());
    document.getElementById('export_report1_').click();
  }else if (type == 4){
    if ($('#interval_type').val() == 1){
      $("#interval_type_").val(3);
      $("#interval_branchid_").val($("#branchid_reports").val());
      $("#interval_date1").val($("#interval_date").val());
      document.getElementById('export_interval_hourly').click();
    }else if  ($('#interval_type').val() == 2){
      $("#interval_branchid_daily").val($("#branchid_reports").val());
      $("#interval_date1_daily").val($("#interval_daily_from").val());
      $("#interval_date2_daily").val($("#interval_daily_to").val());
      document.getElementById('export_interval_daily').click();
    }else if  ($('#interval_type').val() == 3){
      $("#interval_branchid_weekly").val($("#branchid_reports").val());
      $("#interval_month_weekly").val($("#weekly_month").val());
      document.getElementById('export_interval_weekly').click();
    }
  }
}

function exportToExcelConfirm(){

  var branch = $("#cmbBranches_confirm").val();
  $("#row_branch_confirm").val(branch);
  document.getElementById('export_confirm').click();
}

function exportToExcelRerouted(){

  var branch = $("#cmbBranches_rerouted").val();
  $("#row_branch_rerouted").val(branch);
  document.getElementById('export_rerouted').click();
}

function exportToExcelPending1(){

  var branch = $("#cmbBranches_pending1").val();
  $("#row_branch_pending1").val(branch);
  document.getElementById('export_pending1').click();
}

function exportToExcelPending(){

  var branch = $("#cmbBranches_pending").val();
  $("#row_branch_pending").val(branch);
  document.getElementById('export_pending').click();
}

function exportToExcelMessage(){

    document.getElementById('export_message').click();
}


function getCounts(){
  setInterval("getCountStatus()",1000);
  setInterval("getBranchStatus()",1000);
  setInterval("loadTableOrders('1','#alltables')",60000);
}

function filterReports(){
   var type = $("#type_reports").val();

   if (type == 1){
     var branch = $("#branchid_reports").val();
     var from = $("#date1_reports").val();
     var to = $("#date2_reports").val();

     $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'http://localhost/ordertakingcrmv1/Supervisor/filterReports',
      data:{'type': type,
            'branch': branch,
            'from': from,
            'to': to},
      success: function(data) {
        $('#reportstable').html(data);
        $('.dynamic-table').DataTable({ 
          "destroy": true, 
        });
        $('.dynamic-table').css('width','100%');
      },
      error: function(data){
       // alert("error");
      }
    });
   }else  if (type == 2){
     var branch = $("#branchid_reports").val();
     var from = $("#date1_reports").val();
     var to = $("#date2_reports").val();

     $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'http://localhost/ordertakingcrmv1/Supervisor/filterReports',
      data:{'type': type,
            'branch': branch,
            'from': from,
            'to': to},
      success: function(data) {
        $('#reportstable').html(data);
        $('.dynamic-table').DataTable({ 
          "destroy": true, 
        });
        $('.dynamic-table').css('width','100%');
      },
      error: function(data){
       // alert("error");
      }
    });
   }else if (type == 3){
     var branch = $("#branchid_reports").val();
     var from = $("#date1_reports").val();
     var to = $("#date2_reports").val();

     $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'http://localhost/ordertakingcrmv1/Supervisor/filterReports',
      data:{'type': type,
            'branch': branch,
            'from': from,
            'to': to},
      success: function(data) {
        $('#reportstable').html(data);
        $('.dynamic-table').DataTable({ 
          "destroy": true, 
        });
        $('.dynamic-table').css('width','100%');
      },
      error: function(data){
       // alert("error");
      }
    });
   }else if (type == 4){
     var branch = $("#branchid_reports").val();
     var date = $("#interval_date").val();
     var interval = $("#interval_type").val();

     if (interval == '1'){
        $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterIntervalHourly',
        data:{'branch': branch,
              'date': date},
        success: function(data) {
          $('#reportstable').html(data);
          $('.dynamic-table').DataTable({ 
            "destroy": true, 
          });
          $('.dynamic-table').css('width','100%');
        },
        error: function(data){
         // alert("error");
        }
      });
     }else if (interval == '2'){

     var from = $("#interval_daily_from").val();
     var to = $("#interval_daily_to").val();

       $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterIntervalDaily',
        data:{'branch': branch,
              'from': from,
              'to': to},
        success: function(data) {
          $('#reportstable').html(data);
          $('.dynamic-table').DataTable({ 
            "destroy": true, 
          });
          $('.dynamic-table').css('width','100%');
        },
        error: function(data){
         // alert("error");
        }
      });
     }else if (interval == '3'){

     var week = $("#weekly_month").val();

       $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterIntervalWeekly',
        data:{'branch': branch,
              'week': week},
        success: function(data) {
          $('#reportstable').html(data);
          $('.dynamic-table').DataTable({ 
            "destroy": true, 
          });
          $('.dynamic-table').css('width','100%');
        },
        error: function(data){
         // alert("error");
        }
      });
     }
   }else if (type == 5){
     var branch = $("#branchid_reports").val();
     var interval = $("#bar_type").val();

     if (interval == '1'){
      var from = $("#bar_date").val();
      var to = $("#bar_date_to").val();

        $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterBarDaily',
        data:{'branch': branch,
              'from': from,
              'to': to},
        success: function(data) {
        LoadNewDataFromDIV(data);
        },
        error: function(data){
         // alert("error");
        }
      });
     }else if (interval == '2'){
      var month = $("#bar_month").val();
        $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterBarWeekly',
        data:{'branch': branch,
              'month':month},
        success: function(data) {
        LoadNewDataFromDIV(data);
        },
        error: function(data){
         // alert("error");
        }
      });
     }else if (interval == '3'){

       $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'http://localhost/ordertakingcrmv1/Supervisor/filterBarMonthly',
        data:{'branch': branch},
        success: function(data) {
          //alert(data);
        LoadNewDataFromDIV(data);
        },
        error: function(data){
         // alert("error");
        }
      });
     }
   }
}

function filterOnline(){
  var branch = $("#cmbBranches").val();
  var date = $("#id-date-picker-online").val();
  date = date.split("-");
  date = date[2] + "-" + date[1] + "-" + date[0];

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterOnline',
    data:{'branch': branch,
          'date': date},
    success: function(data) {
      $('#alltables').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}




function filterConfirm(){
  var branch = $("#cmbBranches_confirm").val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterConfirm',
    data:{'branch': branch},
    success: function(data) {
      $('#confirmtable').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}

function filterRerouted(){
  var branch = $("#cmbBranches_rerouted").val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterRerouted',
    data:{'branch': branch},
    success: function(data) {
      $('#misroutedtable').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}
function filterPending1(){
  var branch = $("#cmbBranches_pending1").val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterPending1',
    data:{'branch': branch},
    success: function(data) {
      $('#pending1table').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}

function filterPending(){
  var branch = $("#cmbBranches_pending").val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterPending',
    data:{'branch': branch},
    success: function(data) {
      $('#pendingtable').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}

function loadStoreMessage(){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/getStoreMessage',
    success: function(data) {
      $('#storemessagetable').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
    //  alert("error");
    }
  });
}

function filterHitRate(){
  var branch = $("#cmbBranches1").val();
  $("#is_refreshed").val(0);
  var date = $("#id-date-picker-hitrate").val();
  var date1 = $("#id-date-picker-hitrate1").val();
  date = date.split("-");
  date = date[2] + "-" + date[1] + "-" + date[0];
  date1 = date1.split("-");
  date1 = date1[2] + "-" + date1[1] + "-" + date1[0];

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/filterHitRate',
    data:{'branch': branch,
          'date': date,
          'date1': date1},
    success: function(data) {
      $('#hitratetable').html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
    //  alert("error");
    }
  });
}


function loadHitRateTable(num, table){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/loadHitRateTable',
    data:{'num': num},
    success: function(data) {
      $(table).html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
   //   alert("error");
    }
  });

  $("#is_refreshed").val(1);
}

function loadBranchTable(num, table){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/loadBranchTable',
    data:{'num': num},
    success: function(data) {
      $(table).html(data);
      $('.dynamic-table').DataTable({ 
        "destroy": true, 
      });
      $('.dynamic-table').css('width','100%');
    },
    error: function(data){
     // alert("error");
    }
  });
}

function saveTransaction(order_id,num,branchid,xdate){
	if(branchid=='' && (num==1  || num==2 )){
    orderModal.click();
    $('#errorBody').text("No branch selected.");
    $('#error-modal').modal('show');
    return false;

  }
  $.ajax({
    type: 'POST',
    dataType: 'html',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/saveTransaction',
    data:{'order_id': order_id,'num': num,'branchid': branchid,'xdate': xdate	  
  },
  success: function(result) {
    orderModal.click();
	if(result==""){
		$('#successBody').text("Order status successfully saved.");
	}else{
		$('#successBody').text(result);	
	}
    $('#success-modal').modal('show');
    window.setTimeout(function(){location.reload()},2000);
  },
  error: function(data){
    orderModal.click();
    $('#errorBody').text("Something went wrong.");
    $('#error-modal').modal('show');
  }
});
}

function openOrderDetails(stat,id){
  $('#orderModal').click();
  if(stat == 'WAITING'){
    $('#btnConfirm').addClass('noclickme');
    $('#btnDone').addClass('noclickme');
    $('#btnRoute').addClass('noclickme');
    $('#btnVoid').addClass('noclickme');
    $('#btnRelayed').removeClass('noclickme');

  }else if(stat == 'MISROUTE'){
    $('#btnRelayed').addClass('noclickme');
    $('#btnConfirm').addClass('noclickme');
    $('#btnDone').addClass('noclickme');
    $('#btnRoute').removeClass('noclickme');
    $('#btnVoid').removeClass('noclickme');
  }else if(stat == 'CONFIRMED'){
    $('#btnRelayed').addClass('noclickme');
    $('#btnDone').addClass('noclickme');
    $('#btnRoute').addClass('noclickme');
    $('#btnVoid').addClass('noclickme');
    $('#btnConfirm').removeClass('noclickme');
  }else if(stat == 'VOID'){
    $('#btnRelayed').addClass('noclickme');
    $('#btnRoute').addClass('noclickme');
    $('#btnVoid').addClass('noclickme');
    $('#btnConfirm').addClass('noclickme');
    $('#btnDone').removeClass('noclickme');
  }else{
    $('#btnRelayed').removeClass('noclickme');
    $('#btnDone').removeClass('noclickme');
    $('#btnRoute').removeClass('noclickme');
    $('#btnVoid').removeClass('noclickme');
    $('#btnConfirm').removeClass('noclickme');
  }
  $.ajax({
    type: 'POST',
    url: 'http://localhost/ordertakingcrmv1/Supervisor/orderDetails',
    data:{'rowid': id},
    success: function(data) {
      var result = data.split("?");
      $('#ordID').text(result[3]);
      $('#orderStatus').html(result[0]);
      $('#customerHistory').html(result[1]);
      $('#orderHistory').html(result[2]);
    },
    error: function(data){
    //  alert("error");
    }
  });
  


}

function getBranchStatus(){
 $.ajax({
  type: 'POST',
  dataType: 'json',
  url: 'http://localhost/ordertakingcrmv1/Supervisor/getBranchStatus',
  success: function(result) {
    var xready=0;
    var xbusy=0;
    var xonline=0;
    var xoffline=0;

    $.each(result, function(key, value) {
      if(value.type=='BUSY'){
       xbusy=value.xcnt;
     }else if(value.type=='READY'){
      xready=value.xcnt;
    }else if(value.type=='OFFLINE'){
     xoffline=value.xcnt;
   }else if(value.type=='ONLINE'){
     xonline=value.xcnt;
   }


 });
    $("#xready").text(xready);
    $("#xbusy").text(xbusy);
    $("#xonline").text(xonline);
    $("#xoffline").text(xoffline);

  },
  error: function(data){
  // alert("error");
  }
});
}


function getCountStatus(){
 $.ajax({
  type: 'POST',
  dataType: 'json',
  url: 'http://localhost/ordertakingcrmv1/Supervisor/getCountStatus',
  success: function(result) {
    var xonlines=0;
    var xpending=0;
    var xmisrouted=0;
    var xconfirm=0;
    var xvoid=0;
    var xsifup=0;
    var xbranch=0;

    $.each(result, function(key, value) {
      if(value.type=='ONLINE'){
       xonlines=value.xcnt;
     }else if(value.type=='PENDING'){
       xpending=value.xcnt;
     }else if(value.type=='MISROUTED'){
      xmisrouted=value.xcnt;
    }else if(value.type=='CONFIRM'){
     xconfirm=value.xcnt;
   }else if(value.type=='VOID'){
     xvoid=value.xcnt;
   }else if(value.type=='SI-FFUP'){
     xsifup=value.xcnt;
   }else if(value.type=='BRANCH'){
     xbranch=value.xcnt;
   }


 });
    $("#xonlines").text(xonlines);
    $("#xpending").text(xpending);
    $("#xmisrouted").text(xmisrouted);
    $("#xconfirm").text(xconfirm);
    $("#xvoid").text(xvoid);
    $("#xsifup").text(xsifup);
    $("#xbranch").text(xbranch);




  },
  error: function(data){
  //  alert("error");
  }
});
}

function pieChart(){

  var data = $("#chart4_").val();
  var tojson = JSON.parse(data);

  var chart;
  var legend;


  AmCharts.ready(function () {
      // PIE CHART
      chart = new AmCharts.AmPieChart();
      chart.dataProvider = tojson;
      chart.titleField = "stat";
      chart.valueField = "total";
      chart.outlineColor = "#FFFFFF";
      chart.outlineAlpha = 0.8;
      chart.outlineThickness = 2;

      // WRITE
      chart.write("chartdiv");
    });
}

function barGraph(){
  var data = $("#chart3_").val();
  var tojson = JSON.parse(data);

  var chart;

  AmCharts.ready(function () {
      // SERIAL CHART
      chart = new AmCharts.AmSerialChart();
      chart.dataProvider = tojson;
      chart.categoryField = "sub_item";
      chart.startDuration = 1;

      // AXES
      // category
      var categoryAxis = chart.categoryAxis;
      categoryAxis.labelRotation = 45; // this line makes category values to be rotated
      categoryAxis.gridAlpha = 0;
      categoryAxis.fillAlpha = 1;
      categoryAxis.fillColor = "#FAFAFA";
      categoryAxis.gridPosition = "start";

      // value
      var valueAxis = new AmCharts.ValueAxis();
      valueAxis.dashLength = 5;
      valueAxis.title = "Most Ordered Item";
      valueAxis.axisAlpha = 0;
      chart.addValueAxis(valueAxis);

      // GRAPH
      var graph = new AmCharts.AmGraph();
      graph.valueField = "total";
      graph.color = "#3498DB";
      graph.balloonText = "<b>[[category]]: [[value]]</b>";
      graph.type = "column";
      graph.lineAlpha = 0;
      graph.fillAlphas = 1;
      chart.addGraph(graph);

      // CURSOR
      var chartCursor = new AmCharts.ChartCursor();
      chartCursor.cursorAlpha = 0;
      chartCursor.zoomable = false;
      chartCursor.categoryBalloonEnabled = false;
      chart.addChartCursor(chartCursor);

      chart.creditsPosition = "top-right";

      // WRITE
      chart.write("chartdiv2");
    });
}


function lineChart10(test){
  var data = $("#chart10_").val();
  var tojson = JSON.parse(test);


  var chart;

  AmCharts.ready(function () {
            // SERIAL CHART
            chart = new AmCharts.AmSerialChart();
            chart.dataProvider = tojson;
            chart.categoryField = "branch";
            chart.color = "#FFFFFF";
            chart.fontSize = 14;
            chart.startDuration = 1;
            chart.plotAreaFillAlphas = 0.2;
            // the following two lines makes chart 3D
            chart.angle = 30;
            chart.depth3D = 60;

            // AXES
            // category
            var categoryAxis = chart.categoryAxis;
            categoryAxis.gridAlpha = 0.2;
            categoryAxis.gridPosition = "start";
            categoryAxis.gridColor = "#FFFFFF";
            categoryAxis.axisColor = "#FFFFFF";
            categoryAxis.axisAlpha = 0.5;
            categoryAxis.dashLength = 5;

            // value
            var valueAxis = new AmCharts.ValueAxis();
            valueAxis.stackType = "3d"; // This line makes chart 3D stacked (columns are placed one behind another)
            valueAxis.gridAlpha = 0.2;
            valueAxis.gridColor = "#FFFFFF";
            valueAxis.axisColor = "#FFFFFF";
            valueAxis.axisAlpha = 0.5;
            valueAxis.dashLength = 5;
            valueAxis.title = "Bar Graph";
            valueAxis.titleColor = "#FFFFFF";
            valueAxis.unit = "";
            chart.addValueAxis(valueAxis);

            // GRAPHS
            // first graph
            var graph1 = new AmCharts.AmGraph();
            graph1.title = "2004";
            graph1.valueField = "counts";
            graph1.type = "column";
            graph1.lineAlpha = 0;
            graph1.lineColor = "#D2CB00";
            graph1.fillAlphas = 1;
            graph1.balloonText = "GDP grow in [[category]] (2004): <b>[[value]]</b>";
            chart.addGraph(graph1);

            // second graph
            var graph2 = new AmCharts.AmGraph();
            graph2.title = "2005";
            graph2.valueField = "total";
            graph2.type = "column";
            graph2.lineAlpha = 0;
            graph2.lineColor = "#BEDF66";
            graph2.fillAlphas = 1;
            graph2.balloonText = "GDP grow in [[category]] (2005): <b>[[value]]</b>";
            chart.addGraph(graph2);

            chart.write("chartdiv10");
        });
 
}

function lineChart(){
  var chart;
  
  var data = $("#chart2_").val();
  var tojson = JSON.parse(data);

  var average = 90.4;

  AmCharts.ready(function () {

      // SERIAL CHART
      chart = new AmCharts.AmSerialChart();

      chart.dataProvider = tojson;
      chart.categoryField = "date";
      chart.dataDateFormat = "YYYY-MM-DD";

      // AXES
      // category
      var categoryAxis = chart.categoryAxis;
      categoryAxis.parseDates = true; // as our data is date-based, we set parseDates to true
      categoryAxis.minPeriod = "DD"; // our data is daily, so we set minPeriod to DD
      categoryAxis.dashLength = 1;
      categoryAxis.gridAlpha = 0.15;
      categoryAxis.axisColor = "#DADADA";

      // value
      var valueAxis = new AmCharts.ValueAxis();
      valueAxis.axisColor = "#DADADA";
      valueAxis.dashLength = 1;
      valueAxis.logarithmic = true; // this line makes axis logarithmic
      chart.addValueAxis(valueAxis);

      // GUIDE for average
      var guide = new AmCharts.Guide();
      guide.value = average;
      guide.lineColor = "#CC0000";
      guide.dashLength = 4;
      guide.label = "average";
      guide.inside = true;
      guide.lineAlpha = 1;
      valueAxis.addGuide(guide);


      // GRAPH
      var graph = new AmCharts.AmGraph();
      graph.type = "smoothedLine";
      graph.bullet = "round";
      graph.bulletColor = "#FFFFFF";
      graph.useLineColorForBulletBorder = true;
      graph.bulletBorderAlpha = 1;
      graph.bulletBorderThickness = 2;
      graph.bulletSize = 7;
      graph.title = "Total";
      graph.valueField = "total";
      graph.lineThickness = 2;
      graph.lineColor = "#00BBCC";
      chart.addGraph(graph);

      // CURSOR
      var chartCursor = new AmCharts.ChartCursor();
      chartCursor.cursorPosition = "mouse";
      chart.addChartCursor(chartCursor);

      // SCROLLBAR
      var chartScrollbar = new AmCharts.ChartScrollbar();
      chartScrollbar.graph = graph;
      chartScrollbar.scrollbarHeight = 30;
      chart.addChartScrollbar(chartScrollbar);

      chart.creditsPosition = "bottom-right";

      // WRITE
      chart.write("chartdiv3");
    });
}

function lineChart2(){

  var data = $("#chart1_").val();
  var tojson = JSON.parse(data);

  var chart;

  AmCharts.ready(function () {
      // SERIAL CHART
      chart = new AmCharts.AmSerialChart();
      chart.dataProvider = tojson;
      chart.categoryField = "branch";
      chart.startDuration = 1;
      chart.rotate = true;

      // AXES
      // category
      var categoryAxis = chart.categoryAxis;
      categoryAxis.gridPosition = "start";
      categoryAxis.axisColor = "#DADADA";
      categoryAxis.dashLength = 3;

      // value
      var valueAxis = new AmCharts.ValueAxis();
      valueAxis.dashLength = 3;
      valueAxis.axisAlpha = 0.2;
      valueAxis.position = "top";
      valueAxis.minorGridEnabled = true;
      valueAxis.minorGridAlpha = 0.08;
      valueAxis.gridAlpha = 0.15;
      chart.addValueAxis(valueAxis);

      // GRAPHS
      // column graph
      var graph1 = new AmCharts.AmGraph();
      graph1.type = "column";
      graph1.title = "Orders";
      graph1.valueField = "total";
      graph1.lineAlpha = 0;
      graph1.fillColors = "#ADD981";
      graph1.fillAlphas = 0.8;
      graph1.balloonText = "<span style='font-size:13px;'>[[title]] in [[category]]:<b>[[value]]</b></span>";
      chart.addGraph(graph1);

      // LEGEND
      var legend = new AmCharts.AmLegend();
      legend.useGraphSettings = true;
      chart.addLegend(legend);

      chart.creditsPosition = "top-right";

      // WRITE
      chart.write("chartdiv4");
    });
}

function getNumberofOrders(date){
  $.ajax({
    type: 'POST',
    dataType: 'json',
   // 'async':false,
    url: 'http://localhost/ordertakingcrmv1/Supervisor/getNumberofOrders',
    data:{'date': date},
    success: function(data) {
      var response = JSON.stringify(data); 
      var count = response.split('count_id":"').pop();
      return count[0];
    },
    error: function(data){
   //   alert("error");
    }
  });
}

function lineChart3(){
  var chart;
  var data = $("#chart8_").val();
  var tojson = JSON.parse(data);

  AmCharts.ready(function () {
  // generate some random data first

  // SERIAL CHART
  chart = new AmCharts.AmSerialChart();

  chart.marginLeft = 0;
  chart.marginRight = 0;
  chart.marginTop = 0;
  chart.dataProvider = tojson;
  chart.categoryField = "date";

  // AXES
  // category
  var categoryAxis = chart.categoryAxis;
  // value axis
  var valueAxis = new AmCharts.ValueAxis();
  valueAxis.inside = true;
  valueAxis.tickLength = 0;
  valueAxis.axisAlpha = 0;
  chart.addValueAxis(valueAxis);

  // GRAPH
  var graph = new AmCharts.AmGraph();
  graph.dashLength = 3;
  graph.lineColor = "#7717D7";
  graph.valueField = "duration";
  graph.dashLength = 3;
  graph.bullet = "round";
  chart.addGraph(graph);

  // CURSOR
  var chartCursor = new AmCharts.ChartCursor();
  chartCursor.cursorAlpha = 0;
  chart.addChartCursor(chartCursor);

  // WRITE
  chart.write("chartdiv8");
  });
}

function lineChart4(){
  var chart;
  var data = $("#chart6_").val();
  var tojson = JSON.parse(data);

  var d = new Date();
  var month = new Array();
  month[0] = "January";
  month[1] = "February";
  month[2] = "March";
  month[3] = "April";
  month[4] = "May";
  month[5] = "June";
  month[6] = "July";
  month[7] = "August";
  month[8] = "September";
  month[9] = "October";
  month[10] = "November";
  month[11] = "December";
  var n = month[d.getMonth()];

  AmCharts.ready(function () {
      chart = new AmCharts.AmSerialChart();
      chart.dataProvider = tojson;
      chart.categoryField = "branch";
      chart.startDuration = 1;

      var categoryAxis = chart.categoryAxis;
      categoryAxis.labelRotation = 45; // this line makes category values to be rotated
      categoryAxis.gridAlpha = 0;
      categoryAxis.fillAlpha = 1;
      categoryAxis.fillColor = "#FAFAFA";
      categoryAxis.gridPosition = "start";

      // value
      var valueAxis = new AmCharts.ValueAxis();
      valueAxis.dashLength = 5;
      valueAxis.title = "Branch Total Sales - " + n;
      valueAxis.axisAlpha = 0;
      chart.addValueAxis(valueAxis);

      // GRAPH
      var graph = new AmCharts.AmGraph();
      graph.valueField = "total";
      graph.colorField = "color";
      graph.balloonText = "<b>[[category]]: [[value]]</b>";
      graph.type = "column";
      graph.lineAlpha = 0;
      graph.fillAlphas = 1;
      chart.addGraph(graph);

      // CURSOR
      var chartCursor = new AmCharts.ChartCursor();
      chartCursor.cursorAlpha = 0;
      chartCursor.zoomable = false;
      chartCursor.categoryBalloonEnabled = false;
      chart.addChartCursor(chartCursor);

      chart.creditsPosition = "top-right";

      // WRITE
      chart.write("chartdiv6");
  });
}

function lineChart5(){
var chart;
var data = $("#chart7_").val();
var tojson = JSON.parse(data);

AmCharts.ready(function () {
  // SERIAL CHART
  chart = new AmCharts.AmSerialChart();
  chart.dataProvider = tojson;

  chart.categoryField = "date";
  chart.dataDateFormat = "YYYY-MM-DD";

  var balloon = chart.balloon;
  balloon.cornerRadius = 6;
  balloon.adjustBorderColor = false;
  balloon.horizontalPadding = 10;
  balloon.verticalPadding = 10;

  // AXES
  // category axis
  var categoryAxis = chart.categoryAxis;
  categoryAxis.parseDates = true; // as our data is date-based, we set parseDates to true
  categoryAxis.minPeriod = "DD"; // our data is daily, so we set minPeriod to DD
  categoryAxis.autoGridCount = false;
  categoryAxis.gridCount = 50;
  categoryAxis.gridAlpha = 0;
  categoryAxis.gridColor = "#000000";
  categoryAxis.axisColor = "#555555";

  // as we have data of different units, we create two different value axes
  // Duration value axis
  var durationAxis = new AmCharts.ValueAxis();
  durationAxis.gridAlpha = 0.05;
  durationAxis.axisAlpha = 0;
  chart.addValueAxis(durationAxis);

  var durationGraph = new AmCharts.AmGraph();
  durationGraph.title = "duration";
  durationGraph.valueField = "duration";
  durationGraph.type = "line";
  durationGraph.valueAxis = durationAxis; // indicate which axis should be used
  durationGraph.lineColorField = "lineColor";
  durationGraph.fillColorsField = "lineColor";
  durationGraph.fillAlphas = 0.3;
  durationGraph.balloonText = "[[value]]";
  durationGraph.lineThickness = 1;
  durationGraph.legendValueText = "[[value]]";
  durationGraph.bullet = "square";
  durationGraph.bulletBorderThickness = 1;
  durationGraph.bulletBorderAlpha = 1;
  chart.addGraph(durationGraph);

  // CURSOR
  var chartCursor = new AmCharts.ChartCursor();
  chartCursor.zoomable = false;
  chartCursor.categoryBalloonDateFormat = "YYYY MMM DD";
  chartCursor.cursorAlpha = 0;
  chart.addChartCursor(chartCursor);


  var chartScrollbar = new AmCharts.ChartScrollbar();
  chart.addChartScrollbar(chartScrollbar);

  // WRITE
  chart.write("chartdiv7");
});
}

function zoomChart() {
  chart.zoomToIndexes(chartData.length - 40, chartData.length - 1);
}

            