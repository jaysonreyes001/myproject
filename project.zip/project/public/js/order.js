
$(document).ready(function(){

  $('#btnAdd').click(function(e){
     var id = $('#txtID').val();
   
     var branch = $('#txtBranch').val();
	 var order_stat = $('#order_stats').find('option:selected').val();	
	 var code = $('#txtCode').val();
	 var stat = $('#txtStatus').val();
	 var type = $('#txtType').val();
	 var date_inserted = $('#txtCutoff').val();
	 var cfirst_name = $('#txtcFirstName').val();
	 var clast_name = $('#txtcLastName').val();
	 var ctelephone = $('#txtcTel').val();
	 var cmobile = $('#txtcMobile').val();
	 var cemail = $('#txtcEmail').val();
	 var cgoldilockscard = $('#txtcGoldi').val();
	 var rfirst_name = $('#txtrFirstName').val();
	 var rlast_name = $('#txtrLastName').val();
	 var rtelephone = $('#txtrTel').val();
	 var rmobile = $('#txtrMobile').val();
	 var remail = $('#txtrEmail').val();
	 var address_type = $('#txtAddressType').val();
	 var building = $('#txtBuilding').val();
	 var city = $('#txtCity').val();
	 var number = $('#txtNumber').val();
	 var street = $('#txtStreet').val();
	 var barangay = $('#txtBarangay').val();
	 var landmark = $('#txtlandmark').val();
	 var remarks = $('#txtRemarks').val();
	 var longitude = $('#txtLong').val();
	 var latitude = $('#txtLat').val();

	 
 
    var site = $('#site_url').val();
    $.ajax({
     url:'edit_status',
     type:"post",
     data:{ id:id,
			code:code,
			stat:stat,
			type:type,
			date_inserted:date_inserted,
			cfirst_name:cfirst_name,
			clast_name:clast_name,
			ctelephone:ctelephone,
			cmobile:cmobile,
			cemail:cemail,
			cgoldilockscard:cgoldilockscard,
			rfirst_name:rfirst_name,
			rlast_name:rlast_name,
			rtelephone:rtelephone,
			rmobile:rmobile,
			remail:remail,
			address_type:address_type,
			building:building,
			city:city,
			number:number,
			street:street,
			barangay:barangay,
			landmark:landmark,
			remarks:remarks,
			longitude:longitude,
			latitude:latitude,
            branch: branch,
			
			order_stat: order_stat,
           },
       success: function(data){
        alert("Order has been routed successfully.");
        setTimeout(function(){window.location.href=site;}, 1000);
      }
    });
  });

  $('#btnCancel').click(function(e){
    var site = $('#site_url').val();
    window.location.href=site;
  });

});
