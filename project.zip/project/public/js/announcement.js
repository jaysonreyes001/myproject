$('#dashboard_li').removeClass('active');
$('#announcement_li').addClass('active'); 

$(document).ready(function(){

  //if (localStorage.getItem("SelectedItem") != null) {
    var selectedItem = sessionStorage.getItem("SelectedItem");  
    if (selectedItem != ""){
      $('#website_selected').val(selectedItem);
      loadTable(selectedItem);
    }
 /* }else{

  }*/

  $('#datepicker').datepicker({
      autoclose: true
    });

  $(".website").click(function(){
       var id = "#"+this.id;
       $(".website").removeClass("active");
       $(id).addClass("active");
  });

  $("#website_selected").change(function () {
        var id = $("#website_selected").val();
        loadTable(id);
        sessionStorage.setItem("SelectedItem", id);
    });

  $('#submit').submit(function(e){
    var title = $('#title').val();
    var desc = $('#description1').val();
    var type = $('#cboAnnouncementType').val();
    var website = $('#website_id').val();
    var expiration = $('#datepicker').val();
    e.preventDefault(); 
    $.ajax({
     url:'Announcement/saveAnnouncement',
     type:"post",
     data:{title: title,
       description: desc,
       type: type,
       website:website,
       expiration: expiration},
       success: function(data){
        $('#newHiring').modal('hide');
        alert("Announcement saved successfully.");
        location.reload(3000);
      }
    });
  });

  $('#announcement_type').click(function(e){
    $(".btnSelect").removeClass("noclickme");
    $('#announcement_row').css('display','block');
  });

  var myTable = 
   $('.dynamic-table')
      .DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : true,
        bAutoWidth: true,
        "aoColumns": [
          { "bSortable": false },
          null, null,null, null, null,
          { "bSortable": false }
        ],
        "aaSorting": [],
        select: {
            style: 'multi'
          }
      });
});

function displayRandom(){
  var website = $('#website_id').val();
    $(".btnSelect").addClass("noclickme");
    $('#announcement_row').css('display','none');
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'Announcement/editAnnouncementDisplay',
      data:{
        'type'  : 'Random',
        'website': website
      },
      success: function(data) {
      },
      error: function(data){
        console.log("error");
      }
    });
}

function loadTable(id){

  $("#website_id").val(id);

  $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'Announcement/loadTable',
      data:{'num': id},
      success: function(data) {
        $('#tableDiv').html(data);
        $('.dynamic-table').DataTable({ 
            "destroy": true, 
         });
        $('.dynamic-table').css('width','100%');
      },
      error: function(data){
      alert("error");
      }
  });

  getDisplayedAnnouncement(id);
  getWebsiteAnnouncement(id);
}

function getDisplayedAnnouncement(id){

  $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'Announcement/getDisplayedAnnouncement',
      data:{'num': id},
      success: function(data) {
        $('#displayed_announcement').html(data);
      },
      error: function(data){
        console.log("no annoucnement");
      }
  });
}

function getWebsiteAnnouncement(id){
  $.ajax({
      type: 'POST',
      dataType: 'json',
      url: 'Announcement/getWebsiteAnnouncement',
      data:{'num': id},
      success: function(data) {
        $('#website_announcement').html(data);
      },
      error: function(data){
         console.log("no annoucnement");
      }
  });
}

function selectAnnouncement(id){

  var website = $('#website_id').val();

  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Announcement/setSelected',
    data:{
      'id'  : id,
      'website' : website
    },
    success: function(data) {
      alert("Announcement successfully selected.");
      location.reload(4000);
    },
    error: function(data){
      console.log("error");
    }
  });
}

function deleteHiring(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Announcement/editAnnouncement',
    data:{
      'id'     : id,
      'type'  : 'inactivate'
    },
    success: function(data) {
      alert("Announcement successfully inactivated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function activeHiring(id){
  $.ajax({
    type: 'POST',
    dataType: 'json',
    url: 'Announcement/editAnnouncement',
    data:{
      'id'     : id,
      'type'  : 'activate'
    },
    success: function(data) {
      alert("Announcement successfully activated.");
      location.reload();
    },
    error: function(data){
      alert("error");
    }
  });
}

function newAnnouncement(){

  $('#newHiring').modal('show');
}