
  var chartbar;
  var data = '[{"branch":"All","counts":"3","total":"2545.00"}]';
  var tojson = JSON.parse(data);

  AmCharts.ready(function () {
      // SERIAL CHART
      chartbar = new AmCharts.AmSerialChart();
      chartbar.dataProvider = tojson;
      chartbar.categoryField = "branch";
      chartbar.color = "#15100F";
      chartbar.fontSize = 14;
      chartbar.startDuration = 1;
      chartbar.plotAreaFillAlphas = 0.2;
      // the following two lines makes chart 3D
      chartbar.angle = 30;
      chartbar.depth3D = 60;

      // AXES
      // category
      var categoryAxisbar = chartbar.categoryAxis;
      categoryAxisbar.gridAlpha = 0.2;
      categoryAxisbar.gridPosition = "start";
      categoryAxisbar.gridColor = "#15100F";
      categoryAxisbar.axisColor = "#15100F";
      categoryAxisbar.axisAlpha = 0.5;
      categoryAxisbar.dashLength = 5;

      // value
      var valueAxisbar = new AmCharts.ValueAxis();
      valueAxisbar.stackType = "3d"; // This line makes chart 3D stacked (columns are placed one behind another)
      valueAxisbar.gridAlpha = 0.2;
      valueAxisbar.gridColor = "#15100F";
      valueAxisbar.axisColor = "#15100F";
      valueAxisbar.axisAlpha = 0.5;
      valueAxisbar.dashLength = 5;
      valueAxisbar.title = "Bar Graph";
      valueAxisbar.titleColor = "#15100F";
      valueAxisbar.unit = "";
      chartbar.addValueAxis(valueAxisbar);

      // GRAPHS
      // first graph
      var graph1bar = new AmCharts.AmGraph();
      graph1bar.title = "TC";
      graph1bar.valueField = "counts";
      graph1bar.type = "column";
      graph1bar.lineAlpha = 0;
      graph1bar.lineColor = "#D2CB00";
      graph1bar.fillAlphas = 1;
      graph1bar.balloonText = "TC: <b>[[value]]</b>";
      chartbar.addGraph(graph1bar);

      // second graph
      var graph2bar = new AmCharts.AmGraph();
      graph2bar.title = "Peso Value";
      graph2bar.valueField = "total";
      graph2bar.type = "column";
      graph2bar.lineAlpha = 0;
      graph2bar.lineColor = "#BEDF66";
      graph2bar.fillAlphas = 1;
      graph2bar.balloonText = "Peso Value: <b>[[value]]</b>";
      chartbar.addGraph(graph2bar);

      chartbar.write("chartdiv10");
    });

function LoadNewDataFromDIV(data)
{
  //This function attempts to use a string of objects to pass to the dataprovider setting
  var ChartData = data;
  
  var tojson = JSON.parse(ChartData);
  chartbar.dataProvider = tojson;
  chartbar.validateData();
}