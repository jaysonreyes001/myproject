<?php

/**
 * 
 */
class User_model extends CI_Model
{

	function saveUser($data){
		date_default_timezone_set('Asia/Manila');
		$data['created_date'] = date('Y-m-d H:i:s');
		$this->db->insert('user',$data);
		if($this->db->affected_rows()  == 0){
			return '0';
		}else{
			return '1';
		}

	}

	function checkexist($val,$type){
		$cmd = "SELECT $type from user where $type = '$val' ";
		$result = $this->db->query($cmd);
		return $result->num_rows();
	}

	function login_user($user,$pass){

		$result = $this->db->query("SELECT * from user where (username = '$user' or email = '$user') and password = '$pass' ");

		if($result->num_rows() == 0){
			return "false";
		}
		else{


			$result = json_encode($result->result());
			$result = json_decode($result,true);


			$session_data = array(
				'id' => $result[0]['rowid'],
				'email' => $result[0]['email'],
				'username' => $result[0]['username'],
				'contact' => $result[0]['contact'],
				'firstname' => $result[0]['firstname'],
				'lastname' => $result[0]['lastname'],
				'logged' => TRUE,
				'is_verify' => $result[0]['is_approve'],
				'password' => $result[0]['password']


			);

			$this->session->set_userdata($session_data);

			return "true";
		}

	}

}

?>