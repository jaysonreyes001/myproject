

<?php

/**
 * 
 */
class Dashboard_model extends CI_Model
{
	
	public function get_userlist(){

		$cmd = "SELECT * from user where is_approve  = 0 ";
		$result = $this->db->query($cmd);
		return $result;
	}

	public function verify_user($id){
		$this->db->query("update user set is_approve = 1,approved_by = '".$this->session->userdata('id')."',approved_date = sysdate() where rowid = '$id' ");
	}

	public function get_generalcontact(){
		$cmd = "SELECT * from general";
		$result = $this->db->query($cmd);
		return $result;
	}

	public function saveGeneral($data,$id){

		if($id == ""){
		$this->db->insert('general',$data);
		}
		else{
			$this->db->update('general',$data,'rowid='.$id);
		}
		if($this->db->affected_rows() == 0){
			return "0";
		}
		else{
			return "1";
		}
	}

	public function get_singleGeneralData($id){

		$result = $this->db->query("SELECT * from general where rowid = '$id' order by rowid asc ");
		return $result->result();

	}
	public function checkexist($contact){
		$result = $this->db->query("SELECT rowid from general where contact = '$contact' ");
		return $result;
	}
	public function checkexist_edit($contact,$contact2){
		$result = $this->db->query("SELECT rowid from general where contact = '$contact' and contact != '$contact2' ");
		return $result;
	}
	public function savePrivate($id){

$cmd = "insert into private (general_id,userid) values ('$id','".$this->session->userdata('id')."')   ";
		$result = $this->db->query($cmd);

	}

	public function checkexistprivate($id){

		$result = $this->db->query("SELECT rowid from private where general_id = '$id' and  `userid` = '".$this->session->userdata('id')."'  ");
		return $result->num_rows();
	}

	public function get_privatecontact(){
		$result = $this->db->query("SELECT b.firstname,b.lastname,b.contact,a.rowid FROM private a left JOIN general b ON a.`general_id` = b.`rowid` where a.userid = '".$this->session->userdata('id')."' ");
		return $result;
	}
	public function deletePrivate($id){
		$this->db->query("delete from private where rowid = '$id' ");
		if($this->db->affected_rows() == 0){
			return "0";
		}
		else{
			return "1";
		}
	}


	public function deleteGeneral($id){
		$this->db->query("delete from general where rowid = '$id' ");
	//	$this->db->query("delete from private where general_id = '$id' ");
		if($this->db->affected_rows() == 0){
			return "0";
		}
		else{
			return "1";
		}
	}
}

?>