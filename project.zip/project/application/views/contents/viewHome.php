
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Unauthorize User</h1>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>


<section class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="box">
					<div class="box-body bg-white p-4">
						<div class="table-responsive">
							<table class="table table-striped" id="tbl_userlist">
								<thead>

									<th>FullName</th>
									<th>Contact</th>
									<th>Username</th>
									<th>Email</th>
									<th>Action</th>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<script type="text/javascript">
	var table = '';
	$(function(){

			table = $("#tbl_userlist").DataTable();

	
get_userlist();	

setTimeout(function(){
				alert("This user is not yet authorized, please authorize it first below");

},500)
		

	})






	function get_userlist(){
		table.ajax.url('<?php echo base_url('index.php/dashboard/get_userlist')?>').load(null,false);
	}

	function verify_user(id){


			$.post("<?php echo base_url('index.php/dashboard/verify_user')?>",{id,id}).done(function(data){

				alert("Succesfully authorized user");
				alert("Please login again ");
				if(id == '<?php echo $this->session->userdata('id') ?>' ){
					location.href = '<?php echo base_url('index.php/auth/logout')?>';
				}
				else{
				location.reload();	
				}
				
			
		})

		
	}
</script>