 <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-5" style="margin: auto;">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Login</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <div class="card-body">
              <form id="FormLogin" method="post">
                <div class="card-body" style="padding-bottom: 0px">
                  <span id="message_error" style="display: none"><div class="alert alert-danger"><strong style="font-size: 14px;">
              <i class="ace-icon fa fa-times"></i> Wrong Username and/or Password! </strong><br>Change a few things up and try logging in again.</div></span>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="text" name="email" class="form-control" id="user" placeholder="Enter email or username">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                  </div>
                  <div class="form-group mb-0">
                   <label class="label" style="float: right;">Don't Have Account yet? <a href="<?php echo base_url('index.php/auth/register')?>">Register Here</a></label>
                  </div>
                </div>
              </div>
                <!-- /.card-body -->
                <div class="card-footer" >
                  <button type="submit" style="float: right;" class="btn btn-primary">Login</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
        
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>


<script type="text/javascript">
  

$("#FormLogin").on('submit',function(e){
  e.preventDefault();
  var user = $("#user").val();
  var pass = $("#password").val();



  $.post("<?php echo base_url('index.php/auth/login_user')?>",{user:user,pass:pass}).done(function(data){
    if(data == "false"){
      $("#message_error").css('display','');
      $("#user").val("");
      $("#password").val("");
      $("#user").focus();
    }
    else{
      location.href="<?php echo base_url('index.php/dashboard')?>";
    }
  })

})

</script>