
<style type="text/css">
	th, td { white-space: nowrap; }
    div.dataTables_wrapper {
        margin: 0 auto;
    }
</style>


    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-12">
       

            
            	<div class="d-flex justify-content-between align-items-center">
            		     <h1 class="m-0">General Contact</h1>
            <button class="btn btn-primary" id="modal_btn"><span class="fa fa-plus"></span> Add General Contact</button>
            	
            </div>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>


<section class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="box">
					<div class="box-body bg-white p-4">
						<div class="table-responsive">
							<table class="table table-striped" id="tbl" style="width: 100%">
								<thead>

									<th>First Name</th>
									<th>Last Name</th>
									<th>Contact</th>
									<th>Action</th>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<div class="modal" id="modal_general">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title"><span id="action"></span> General Contact</h3>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
			</div>
			
			<div class="modal-body">
				<div class="form-group">
					<label>FirstName</label>
					<input type="text" class="form-control" name="" id="firstname" placeholder="Enter a Firstname">
				</div>
				<div class="form-group">
					<label>LastName</label>
					<input type="text" class="form-control" name="" id="lastname" placeholder="Enter a Lastname">
				</div>

			<div class="form-group">
					<label>Contact Number</label>
					<input type="text" class="form-control" onkeypress="return isNumberKey(event)" name="" maxlength="11" id="contact" placeholder="Enter a Contact number">
					 <span class="text-danger text-error-size" id="contact_error"></span>
				</div>
			</div>
			<div class="modal-footer">
				<button data-dismiss='modal' style="margin-right: auto;" class="btn btn-default">Cancel</button>
				<button class="btn btn-primary" onclick="saveGeneral()"><span id="action_btn"></span></button>
				<input type="hidden" id="rowid" value="" name="">
				<input type="hidden" id="contact_" name="">
			</div>
		
		</div>
	</div>
</div>

<script type="text/javascript">
	var error = 0;
	$("#general").addClass('active');

	$("#modal_btn").click(function(){
		$("#action").text("Add");
		$("#action_btn").text("Add");
		clearData();
		$("#modal_general").modal('show');
	})

var table = "";
	$(function(){
		table = $("#tbl").DataTable({
			order:[]
		});
		get_generalcontact();
	})


	function get_generalcontact(){
		table.ajax.url("<?php echo base_url('index.php/dashboard/get_generalcontact')?>").load(null,false);
	}

	function saveGeneral(){
		var firstname = $("#firstname").val();
		var lastname = $("#lastname").val();
		var contact = $("#contact").val();
		var rowid = $("#rowid").val();
var c = 0;
			if(contact.length <11){
				c = 1;
					$("#contact_error").text('Contact number must be 11 digits');
		$("#contact").css('border-color','#dc3545');
			}
			else{
				$("#contact_error").text('');
				$("#contact").css('border-color','');
				c = 0;
			}

			if(error > 0){
					$("#contact_error").text('Contact number already exist');
		$("#contact").css('border-color','#dc3545');
			}
if(error == 0 && c == 0){
		$.post("<?php echo base_url('index.php/dashboard/saveGeneral')?>",{firstname:firstname,lastname:lastname,contact:contact,id:rowid}).done(function(data){
			if(data == 0){
				alert("No Changes");
			}
			else{
				var text = "";
				if($("#action").text() == "Add"){
						text = "Added Successfully";
				}
				else{
						text = "Updated Successfully";
				}
				alert(text);
				location.reload();
			}
		})
	}
}


	function get_dataedit(id){
		$.post("<?php echo base_url('index.php/dashboard/get_singleGeneralData')?>",{id:id}).done(function(data){
			var details = JSON.parse(data);
		
			$("#firstname").val(details[0].firstname);
			$("#lastname").val(details[0].lastname);
			$("#contact").val(details[0].contact);
			$("#contact_").val(details[0].contact);
				$("#action").text("Edit");
				$("#action_btn").text("update");
			$("#rowid").val(id);
			$("#modal_general").modal('show');
		})
	}


	function clearData(){
		$("#firstname").val("");
		$("#lastname").val("");
		$("#contact").val("");
		$("#contact_").val("");
		$("#rowid").val("");

		$("#contact_error").text('');
		$("#contact").css('border-color','');
	}

	 function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

$("#contact").on('blur',function(){

	var contact = $("#contact").val();
	var contact_ = $("#contact_").val();
	var id = $("#rowid").val();
	$.post("<?php echo base_url('index.php/dashboard/checkexist')?>",{contact:contact,contact_:contact_,id:id}).done(function(data){
		if(data >0){
			error=1;
				$("#contact_error").text('Contact number already exist');
		$("#contact").css('border-color','#dc3545');
		}
		else{
			error=0;
				$("#contact_error").text('');
		$("#contact").css('border-color','');
		}
	})

})


function savePrivate(id){


		

	

		$.post("<?php echo base_url('index.php/dashboard/checkexistprivate')?>",{id:id}).done(function(data){
			if(data == 1){
				alert("Contact already save on private contact ")
			}
			else{

					$.post("<?php echo base_url('index.php/dashboard/savePrivate')?>",{id:id}).done(function(data){
						alert("Successfully added to private contact");
					})

				}
		})

	


}


function deleteGeneral(id){


	var con = confirm("Are you sure you want to permanently delete this contact?");

	if(con){

	$.post("<?php echo base_url('index.php/dashboard/deleteGeneral')?>",{id:id}).done(function(data){
		if(data == 1){
			alert("Successfully deleted contact");
			location.reload();
		}
	})
}
else{
	return false;
}

}

</script>