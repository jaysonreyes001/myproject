
<style type="text/css">
	.text-error-size{
		font-size: 14px;
	}
</style> 

 <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
           
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-5" style="margin: auto;">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h2 class="card-title">Register Form</h2>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <div class="card-body">
              <form id="FormRegister">
              	<div class="row">
                <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" id="fname" name="firstname" maxlength="50" placeholder="Enter FirstName">
                        <span class="text-danger text-error-size" id="fname_error"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" id="lname" name="lastname" maxlength="50" placeholder="Enter LastName">
                        <span class="text-danger text-error-size" id="lname_error"></span>
                      </div>
                    </div>
                    </div>


                    <div class="form-group">
                        <label>Contact No.</label>
                        <input type="text" onkeypress="return isNumberKey(event)"  name="contact" maxlength="11" class="form-control" id="contact" placeholder="Enter Contact No.">
                        <span class="text-danger text-error-size" id="contact_error"></span>
                      </div>

                       <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" id="username" name="username" maxlength="50" placeholder="Enter Username">
                        <span class="text-danger text-error-size" id="username_error"></span>
                      </div>

                       <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" id="email" name="email" maxlength="50" placeholder="Enter Email">
                        <span class="text-danger text-error-size" id="email_error"></span>
                      </div>


                      <div class="row">
                <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" id="password" name="password" maxlength="50" placeholder="Enter Password">
                        <span class="text-danger text-error-size" id="password_error"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Retype Password</label>
                        <input type="password" class="form-control" id="repassword" placeholder="Retype Password">
                        <span class="text-danger text-error-size" id="repassword_error"></span>
                      </div>

                    </div>
                    </div>


                   </div>
                <!-- /.card-body -->
                <div class="card-footer">
                	 <label class="label">Back to <a href="<?php echo base_url('index.php/auth/login')?>">Login</a></label>
                  <button type="submit"  style="float: right;" class="btn btn-primary">Register</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->

          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>


<script type="text/javascript">

var c_exist =0,u_exist = 0,e_exist = 0;

$("#FormRegister").on('submit',function(e){
	e.preventDefault();


	var fname = $("#fname").val();
	var lname = $("#lname").val();
	var contact  = $("#contact").val();
	var username = $("#username").val();
	var email = $("#email").val();
	var password = $("#password").val();
	var repassword = $("#repassword").val();

	var f = 0,l =0,c =0,u =0,e = 0,p =0;

	
	if(fname == ""){
		f = 1;
		$("#fname_error").text('Please enter a first name');
		$("#fname").css('border-color','#dc3545');
	}
	else{
		f = 0;
		$("#fname_error").text('');
		$("#fname").css('border-color','');
	}

	if(lname == ""){
		l = 1;
		$("#lname_error").text('Please enter a last name');
		$("#lname").css('border-color','#dc3545');
	}
	else{
		l = 0;
		$("#lname_error").text('');
		$("#lname").css('border-color','');
	}

	if(contact == ""){
		c = 1;
		$("#contact_error").text('Please enter a contact number');
		$("#contact").css('border-color','#dc3545');
	}
	else if(contact.length < 11){
		c = 1;
			$("#contact_error").text('Contact number must be 11 digits');
		$("#contact").css('border-color','#dc3545');
	}
	else if(c_exist == 1){
		$("#contact_error").text('Contact number already exist');
		$("#contact").css('border-color','#dc3545');
	}
	else{


		c=0;
			$("#contact_error").text('');
		$("#contact").css('border-color','');
	}

	if(username == ""){
		u=1;
		$("#username_error").text('Please enter a username');
		$("#username").css('border-color','#dc3545');
	}
	else if(u_exist == 1){

			$("#username_error").text('username already exist');
		$("#username").css('border-color','#dc3545');

	}
	else{
		u=0;
		$("#username_error").text('');
		$("#username").css('border-color','');
	}

	if(email == ""){
		e=1;
		$("#email_error").text('Please enter a email');
		$("#email").css('border-color','#dc3545');
	}
	else if(e_exist == 1){

			$("#email_error").text('email already exist');
		$("#email").css('border-color','#dc3545');

	}
	else{
		u=0;
		$("#email_error").text('');
		$("#email").css('border-color','');
	}

	if(password == ""){
		p=1;
		$("#password_error").text('Please enter a password');
		$("#password").css('border-color','#dc3545');
	}
	else{
		$("#password_error").text('');
		$("#password").css('border-color','');
	}
	if(repassword == ""){
		p = 1;
		$("#repassword_error").text('Please enter a retype password');
		$("#repassword").css('border-color','#dc3545');
	}
	else{
		$("#repassword_error").text('');
		$("#repassword").css('border-color','');
	}
	if(password != "" && repassword != ""){
	if(password != repassword){
		p=1;
		$("#password_error").text('Password not match');
		$("#password").css('border-color','#dc3545');
		$("#repassword").css('border-color','#dc3545');
	}
	else{

		if(password.length < 8){
			p=1;
		$("#password_error").text('Password must be 8 or more character');
		$("#password").css('border-color','#dc3545');
		$("#repassword").css('border-color','#dc3545');
		}
		else{
			p=0;
		$("#password_error").text('');
		$("#password").css('border-color','');
		$("#repassword").css('border-color','');
	}
	}
	}



	if(f == 0 && l == 0 && c == 0 && u == 0 && e == 0 && p == 0 && c_exist == 0 && u_exist == 0 && e_exist == 0){
			$.post("<?php echo base_url('index.php/auth/saveUser')?>",$("#FormRegister").serialize()).done(function(data){
		if(data == 1){
			alert("Registered Successfully");
			location.href="<?php echo base_url('index.php/auth/login')?>";
		}
		else{
			alert("Opps! there's something wrong. Please try again ");
		}
	})
	}
	else{
		return false;
	}

})




  function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

$("#contact").on('blur',function(){
	var contact = $("#contact").val();
		$.post("<?php echo base_url('index.php/auth/checkexist')?>",{val:contact,type:"contact"}).done(function(data){
		
			if(data > 0){
				c_exist = 1;

					$("#contact_error").text('Contact number already exist');
		$("#contact").css('border-color','#dc3545');

			}
			else{
						c_exist = 0;

							$("#contact_error").text('');
		$("#contact").css('border-color','');
		
			}
		})
	})


$("#username").on('blur',function(){
	var contact = $("#username").val();
		$.post("<?php echo base_url('index.php/auth/checkexist')?>",{val:contact,type:"username"}).done(function(data){
		
			if(data > 0){
				u_exist = 1;

					$("#username_error").text('username already exist');
		$("#username").css('border-color','#dc3545');

			}
			else{
						u_exist = 0;

							$("#username_error").text('');
		$("#username").css('border-color','');
		
			}
		})
	})

$("#email").on('blur',function(){
	var contact = $("#email").val();
		$.post("<?php echo base_url('index.php/auth/checkexist')?>",{val:contact,type:"email"}).done(function(data){
		
			if(data > 0){
				e_exist = 1;

					$("#email_error").text('email already exist');
		$("#email").css('border-color','#dc3545');

			}
			else{
						e_exist = 0;

							$("#email_error").text('');
		$("#email").css('border-color','');
		
			}
		})
	})

 </script>