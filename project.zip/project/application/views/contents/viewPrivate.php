
  
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-12">
       


            		     <h1 class="m-0">Private Contact</h1>
            	
            </div>
          </div><!-- /.col -->

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->



<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="box">
          <div class="box-body bg-white p-4">
            <div class="table-responsive">
              <table class="table table-striped" id="tbl">
                <thead>

                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Contact</th>
                  <th>Action</th>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>      

<script type="text/javascript">

  $("#private").addClass('active');
var table = '';
  $(function(){
    table = $("#tbl").DataTable();
    get_privatecontact();

  })


  function get_privatecontact(){
    table.ajax.url('<?php echo base_url("index.php/dashboard/get_privatecontact")?>').load(null,false);

  }
  function deletePrivate(id){
      var con = confirm("Are you sure you want to remove this contact from your list?");
      if(con){
        $.post("<?php echo base_url('index.php/dashboard/deletePrivate')?>",{id:id}).done(function(data){
          if(data == 0){
            alert("Error!! there's something wrong please try again ");
          }
          else{
            alert("Successfully removed from the list ");
            location.reload();
          }
        })
      }
      else{
        return false;
      }
  }
</script>