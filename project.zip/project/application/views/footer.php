</div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="#">TEST PROJECT</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
     
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo base_url('adminlte/')?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url('adminlte/')?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="<?php echo base_url('adminlte/')?>dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?php echo base_url('adminlte/')?>plugins/chart.js/Chart.min.js"></script>



<link href="<?php echo base_url("public/plugins/DataTables");?>/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="<?php echo base_url("public/plugins/DataTables");?>/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="<?php echo base_url("public/plugins/DataTables");?>/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/jszip.min.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/pdfmake.min.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/vfs_fonts.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/buttons.html5.min.js"></script>
    <script src="<?php echo base_url("public/plugins/DataTables");?>/buttons.print.min.js"></script>
<script src="<?php echo base_url("public/dtpicker");?>/jquery.datetimepicker.js"></script>
<script src="<?php echo base_url();?>public/assets/js/select2.full.min.js"></script>
</body>
</html>
