<?php


class Auth extends CI_Controller{

	function __construct(){
		parent::__construct();

		// if(!empty($this->session->userdata('logged'))){
		// 	redirect('dashboard','refresh');
		// }
		// else{
		// 	redirect('auth/login','refresh');
		// }

		$this->load->model('User_model','us');

	}


public function index(){
		
			if($this->session->userdata('logged')){
					if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
					}
					else{
							redirect('dashboard/GeneralContact','refresh');
					}
			
		}
		else{
			redirect('auth/login','refresh');
		}
	}


	public function checkSession(){


		if($this->session->userdata('logged')){

					if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
					}
					else{
							redirect('dashboard/GeneralContact','refresh');
					}
			
		}
		else{
			redirect('auth/login','refresh');
		}

	}

	public function login(){

		if($this->session->userdata('logged')){

					if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
					}
					else{
							redirect('dashboard/GeneralContact','refresh');
					}
			
		}
		else{
			$this->load->view('header');
		$this->load->view('contents/viewLogin');
		$this->load->view('footer');
		}

		

	}

	public function register(){

		$this->load->view('header');
		$this->load->view('contents/viewRegister');
		$this->load->view('footer');

	}


	public function saveUser(){
		echo $this->us->saveUser($_POST);
	}

	public function checkexist(){
		$val = $this->input->post('val');
		$type = $this->input->post('type');
		echo $this->us->checkexist($val,$type);
	}
	public function login_user(){
		$user = $this->input->post('user');
		$pass = $this->input->post('pass');

		$user = $this->db->escape_str($user);
		$pass = $this->db->escape_str($pass);


		echo $this->us->login_user($user,$pass);

	}

	public function logout(){
		session_destroy();
		redirect('auth/login','refresh');
	}

}

?>