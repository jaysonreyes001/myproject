<?php

/**
 * 
 */
class Dashboard extends CI_Controller
{
	

	function __construct(){
		parent::__construct();
		$this->load->model('Dashboard_model','dm');
	}

	public function index(){
		if($this->session->userdata('logged')){
					if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
					}
					else{
							redirect('dashboard/GeneralContact','refresh');
					}
			
		}
		else{
			redirect('auth/login','refresh');
		}
	}

	public function Unauthorizes(){

			if($this->session->userdata('logged')){
		if($this->session->userdata('is_verify') == 1){
							redirect('dashboard/GeneralContact','refresh');
							die();
		}
		}
		else{
			redirect('auth/login','refresh');
		}

		$this->load->view('header');
		$this->load->view('contents/viewHome');
		$this->load->view('footer');
	}

	public function GeneralContact(){
			if($this->session->userdata('logged')){
		if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
							die();
		}
		}
		else{
			redirect('auth/login','refresh');
		}


		$this->load->view('header');
		$this->load->view('contents/viewGeneral');
		$this->load->view('footer');
	}

	public function PrivateContact(){

		if($this->session->userdata('logged')){
			if($this->session->userdata('is_verify') == 0){
							redirect('dashboard/Unauthorizes','refresh');
							die();
			}
		}
			else{
				redirect('auth/login','refresh');
		}
		

		$this->load->view('header');
		$this->load->view('contents/viewPrivate');
		$this->load->view('footer');
	}



	public function verify_user(){
		$id = $this->input->post('id');
		$this->dm->verify_user($id);
	}


	public function get_userlist(){
		$column = array('fullname','username','contact','email','rowid','username');
		$result = $this->dm->get_userlist();

		if($result->num_rows() == 0){
			foreach ($column as $col) {
				$data[]  = 'No Data';
			}
			$output['data'][] = $data;
		}
		else{
			foreach ($result->result_array() as $row) {
				$data = array();
				foreach ($column as $col) {
					if($col == "fullname"){
						$data[] = $row['firstname']." ".$row['lastname'];
					}
					else if($col == "rowid"){
						$data[] = "<a class='btn btn-warning btn-sm' onclick='verify_user(".$row['rowid'].")' ><span>Authorize</span></a>";
					}
					else{
						$data[] = $row[$col];
					}
				}
				$output['data'][] = $data;
			}
			
		}

		echo json_encode($output);
	}




	function get_generalcontact(){
		$column = array('firstname','lastname','contact','rowid');
		$result = $this->dm->get_generalcontact();

		if($result->num_rows() == 0){
			foreach ($column as $row) {
				$data[] = 'No Data';
			}
			$output['data'][] = $data;
		}
		else{

			foreach ($result->result_array() as $row) {
				$data = array();
				foreach ($column as $col) {
					if($col == "rowid"){
						$data[] = "
<a class='btn btn-success btn-sm' title='add private contact' onclick='savePrivate(".$row['rowid'].")' >copy to private contact</a>
						<a class='btn btn-warning btn-sm' onclick='get_dataedit(".$row['rowid'].")' ><span>Edit</span></a>

<a class='btn btn-danger btn-sm' onclick='deleteGeneral(".$row['rowid'].")' ><span class='fas fa-trash'></span></a>
						";

					}
					else{
						$data[] = $row[$col];
					}
				}

				$output['data'][] = $data;
			}

		}

		echo json_encode($output);
	}

	function saveGeneral(){
		$first = $this->input->post('firstname');
		$last = $this->input->post('lastname');
		$contact = $this->input->post('contact');
		$id = $this->input->post('id');


		$data = array(
			'firstname' => $first,
			'lastname' => $last,
			'contact' => $contact,
			'created_by' => $this->session->userdata('id')
		);

	echo	$this->dm->saveGeneral($data,$id);
	}

	function get_singleGeneralData(){
		$id = $this->input->post('id');
		$result = $this->dm->get_singleGeneralData($id);
		echo json_encode($result);
	}

	function checkexist(){
		$contact = $this->input->post('contact');
		$contact_ = $this->input->post("contact_");
		$id = $this->input->post("id");
		if($id == ""){
		$result =  $this->dm->checkexist($contact);	
		}
		else{
			$result =  $this->dm->checkexist_edit($contact,$contact_);	
		}
		
		echo $result->num_rows();
	}

	public function savePrivate(){
		$id = $this->input->post('id');
		echo $this->dm->savePrivate($id);
	}

	public function checkexistprivate(){
		$id = $this->input->post('id');
		echo $this->dm->checkexistprivate($id);
	}

	public function get_privatecontact(){
		$column = array('firstname','lastname','contact','rowid');
		$result = $this->dm->get_privatecontact();
		if($result->num_rows() == 0){
			foreach ($column as $col) {
				$data[] = 'No Data';
			}
			$output['data'][] = $data;
		}
		else{
			foreach ($result->result_array() as $row) {
				$data = array();
				foreach ($column as $col) {
					if($col == "rowid"){
							$data[] = "<a class='btn btn-danger btn-sm' onclick='deletePrivate(".$row['rowid'].")'>Remove</a>";
					}
					else{

						if($row[$col] == null){
							$data[] = '<i>deleted contact</i>';
						}
						else{
						$data[] = $row[$col];
							}
					}
				}
				$output['data'][] = $data;
			}
		}

		echo json_encode($output);
	}

	function deletePrivate(){
		$id = $this->input->post("id");
		echo $this->dm->deletePrivate($id);
	}

	function deleteGeneral(){
		$id = $this->input->post("id");
		echo $this->dm->deleteGeneral($id);
	}
}

?>